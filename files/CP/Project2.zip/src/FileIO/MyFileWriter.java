package FileIO;

import java.io.File;
import UtilityModule.*;

public class MyFileWriter { //자신의 고유한 파일을 소장하고, 그곳에만 정보를 업데이트 하기 위한 FileWriter 객체

    // 객체에서 담당하고 있는 txt 파일의 경로
    private String filePath;

    // filePath의 get method
    public String getFilePath(){
        return filePath;
    }

    public MyFileWriter(String fileName, String folderPath){

        File folder = new File(folderPath);
        folder.mkdir();

        if(folder.exists()) {
            this.filePath=folderPath + File.separator + fileName;
        }
    }

    // file에 Keyword를 쓰는 메서드, RequestHandler의 도움을 받음.
    public void writeKeyword(String Keyword, boolean append){
        RequestHandler.writeFile(this.filePath, Keyword, append);
    }
}
