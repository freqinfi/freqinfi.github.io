package FileIO;

import java.io.File;
import java.util.Collections;
import java.util.LinkedList;
import HTTPServerModule.*;

// 핫 keyword를 관리하는 파일과 자료구조 포함하는 객체(본 프로그램에서 static 변수로 하나만 운용됨)
public class HotKeywordManager extends MyFileWriter{

    // 파일 이름, 파일 상대경로
    private final static String HOTKEWORDLIST_FILENAME = "HotKeywordList.txt";
    private final static String HOTKEWORD_FOLDERPATH = HttpServer.SEARCHAPI_FOLDERPATH + File.separator + "HotKeywordList";

    // 핫 키워드를 관리하는 (검색횟수와 검색키)를 갖는 LinkedList
    private static LinkedList<HotKeywordItem> hotKewordList;

    public HotKeywordManager() {

        super(HOTKEWORDLIST_FILENAME, HOTKEWORD_FOLDERPATH);
        hotKewordList=new LinkedList<>();

    }

    // 핫 키워드 리스트에 add하고, 다시 sort하는 과정
    public void addAndSort(String Keyword) {

        boolean alreadyExist=false;

        for(HotKeywordItem item:hotKewordList) {
            if(item.Keyword.equals(Keyword)) {
                alreadyExist=true;
                item.searchCount+=1;
                break;
            }
        }

        if(!alreadyExist) hotKewordList.add(new HotKeywordItem(1, Keyword));
        Collections.sort(hotKewordList, Collections.reverseOrder());
    }

    // 검색이 완료되면 hotKeyword를 file structure에 업데이트하여
    // 추후 프로그램이 종료되더라도 어떤 것이 가장 많이 검색되었는지 알 수 있고, 10개 넘게 저장할 수 있다.
    public void updateFile() {

        this.writeKeyword("HOTKEWORD LIST", false);
        this.writeKeyword("", true);

        int count=1;

        for(HotKeywordItem item:hotKewordList) {

            String line1 = (count++) + ". Keword : " + item.Keyword;
            String line2 = "Search Count : " + item.searchCount;
            this.writeKeyword(line1, true);
            this.writeKeyword(line2, true);
            this.writeKeyword("", true);

        }
    }

    public void updateAll(String Keyword) {
        addAndSort(Keyword);
        updateFile();
    }

    // hot keyword 자료구조의 내용을 웹에 전시하기 위한 toString 메서드
    @Override
    public String toString() {

        int count = 1;
        StringBuilder sb = new StringBuilder();

        for (HotKeywordItem item : hotKewordList) {
            sb.append("- Rank " +(count++)+" -");
            sb.append(System.lineSeparator());
            sb.append("Keword : " + item.Keyword);
            sb.append(System.lineSeparator());
            sb.append("Search Count : " + item.searchCount);
            sb.append(System.lineSeparator());
            sb.append(System.lineSeparator());
            if(count==11) break;
        }
        return sb.toString();

    }
}

// 검색 횟수와 검색어를 저장하는 class
class HotKeywordItem implements Comparable<HotKeywordItem> {

    public int searchCount;
    public String Keyword;

    public HotKeywordItem(int searchCount, String Keyword) {

        this.searchCount=searchCount;
        this.Keyword=Keyword;

    }

    @Override
    public int compareTo(HotKeywordItem other) {

        int thisVal = this.searchCount;
        int anotherVal = other.searchCount;
        return (Integer.compare(thisVal, anotherVal));

    }

}
