package FileIO;

import java.io.File;
import UtilityModule.*;
import HTTPServerModule.*;
import DataModule.*;

// 웹에서는 관리자가 아이디만 알 수 있으므로, 비밀번호도 알 수 있도록 하는 UserList파일과 Load_log 기능을 위하여
// 이를 저장하는 파일을 관리하는 객체이다. (본 프로그램에서 딱 하나의 객체로만 운용, Admin 객체의 field로 존재한다.)

public class AdminFileWriter extends MyFileWriter{

    static final String ADMIN_FOLDERPATH = HttpServer.SEARCHAPI_FOLDERPATH + File.separator + "Administrator";
    static final String LOADLOG_FILENAME = "Load_log";
    static final String USERLIST_FILEPATH = HttpServer.SEARCHAPI_FOLDERPATH + File.separator + "Administrator" + File.separator + "UserList";

    public AdminFileWriter() {
        super(LOADLOG_FILENAME, ADMIN_FOLDERPATH);

    }

    // User List에 content를 입력하기 위한 메서드
    public void writeUserList(String content, boolean append) {
        RequestHandler.writeFile(USERLIST_FILEPATH, content, append);
    }

    // user 기능을 수행하고 나면 List를 업데이트 해주어야 한다.
    public void updateUserList() {

        int count=1;

        this.writeUserList("USER LIST", false);
        this.writeUserList(" ", true);

        for(User user:UserManager.getUserList()) {

            String line1 = (count++) + ". ID : " + user.getID();
            String line2 = "Password : " + user.getPassword();
            String line3 = "State : " + user.CheckActivate();
            this.writeUserList(line1, true);
            this.writeUserList(line2, true);
            this.writeUserList(line3, true);
            this.writeUserList(" ", true);

        }

    }

}
