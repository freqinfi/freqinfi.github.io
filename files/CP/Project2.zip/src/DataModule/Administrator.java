package DataModule;

import java.util.*;
import UtilityModule.*;
import FileIO.*;

//User을 상속받은 Administrator class
public class Administrator extends User{

    private static LinkedList<User> userList;
    private AdminFileWriter adminFileWriter;

    public Administrator(String Password, boolean isActivate){

        super("admin", Password, isActivate);
        userList=UserManager.getUserList();

        adminFileWriter=new AdminFileWriter();
    }

    public void ActivateAdmin(){
        setActivate(true);
    }

    public void DisabledAdmin() {setActivate(false);}

    public void saveHistory(String log) {this.adminFileWriter.writeKeyword(log, true);}

    public String getHistoryFilepath() {
        return this.adminFileWriter.getFilePath();
    }

    public void updateUserListFile() {
        this.adminFileWriter.updateUserList();
    }

    public String IDList(){

        if(userList.isEmpty()) return ResponseMessege.EMPTY_USER_LIST;

        StringBuilder sb=new StringBuilder();
        sb.append("ID LIST\n");
        sb.append(System.lineSeparator());

        for (User user : userList) {
            sb.append("ID : ");
            sb.append(user.getID());
            sb.append(System.lineSeparator());
            if(user.CheckActivate()) sb.append("State : Activate\n");
            else sb.append("State : Disable\n");

            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }

    public User getFriend(String FreindID) {

        for(User user : userList){
            if(user.getID().equals(FreindID)){
                if(user.CheckActivate()) return user;
                else return UserManager.nullUser;
            }
        }
        return UserManager.nullUser;
    }

}
