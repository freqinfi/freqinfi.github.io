package DataModule;

import java.util.*;
import java.io.*;
import HTTPServerModule.HttpServer;
import UtilityModule.*;

public class UserManager { // 모든 유저의 정보를 저장하고, User 기능 List의 method를 구현하고 있는 객체

    // User의 null 상태를 표현하기 위해서 설계한 static 객체(ID, Password null, 비활성화 상태의 객체이다.)
    public final static User nullUser=new User(null, null, false);

    // SearchAPI의 하위 폴더 Users라는 이름의 고유 폴더를 갖는다.
    static final String USERS_FOLDERPATH = HttpServer.SEARCHAPI_FOLDERPATH + File.separator +"Users";

    // 관리자를 static 변수로 두었다. 한 번에 하나의 유저만 접속할 수 있기 때문에 효율적인 방법이다.
    public static Administrator admin;

    // userList 또한 private static으로 지정하여 권한 외의 class에서 접근이 불가능하도록 설계
    private static LinkedList<User> userList;

    public static LinkedList<User> getUserList(){
        return userList;
    }

    public UserManager(){

        userList=new LinkedList<>();
        File folder = new File(USERS_FOLDERPATH);
        folder.mkdir();

        admin=new Administrator(null, false);
    }

    // 대문자를 소문자로 바꾸기 위해서 존재하는 method
    private String Capital2small(String input){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<input.length();i++){
            sb.append(Character.toLowerCase(input.charAt(i)));
        }
        return new String(sb);
    }

    // 특정한 ID를 받아서 그러한 ID를 갖는 User가 있으면 반환하고, 없다면 nullUser 반환하는 method
    private User ID2User(String ID){
        for(User user : userList){
            if(ID.equals(user.getID())) return user;
        }
        return nullUser;
    }

    // join 과정에서 비밀번호가 올바른 Form인지 확인해주는 method
    private boolean isCorrectForm(String password) {
        return password.matches("^[a-zA-Z][a-zA-Z0-9@#%]{3,}$");
    }

    // 에러 메세지를 전달하는 것은 서버의 역할이므로, 각종 관련 메세지는 ResponseMessege class에서 관리한 후 적절한 messege를 서버에서 웹으로 송신함

    // 회원가입 기능을 담당하는 method
    public String Joining(String ID, String Password) {

        ID=Capital2small(ID);

        if(ID.equals("admin")){

            // admin 계정만 탈퇴하였더라도 다시 재가입하여 admin정보를 덮어쓸 수 있도록 의도하였음(admin의 비밀번호를 바꿀 수 있도록)
            // 즉, SearchAPI에서 admin 계정은 비밀번호를 바꿔서 사용할 수 있고, 일반 유저는 비밀번호를 바꾸지 못한다
            if(admin.getPassword()!=null && admin.CheckActivate()) return ResponseMessege.JOINING_FAIL_ADMIN_EXISTING;

            admin.setPassword(Password);
            admin.ActivateAdmin();
            return ResponseMessege.JOINING_SUCCESS_ADMIN;
        }

        User checkUser=ID2User(ID);

        // join이 실패하는 경우 1. 이미 탈퇴한 아이디인 경우, 2. 이미 존재하는 아이디인 경우, 3. 적절한 form의 비밀번호가 아닌 경우
        // 지금 joining하려는 ID가 원래 UserList에 존재한다면 1. 탈퇴한 아이디, 2. 이미 존재하는 아이디
        // 탈퇴하는 아이디로 joining하는 것을 막아두었음. 항상 recover를 통하여 가능

        if(!(checkUser==nullUser)) {
            if(!checkUser.CheckActivate()) return ResponseMessege.JOINING_FAIL_LEAVE;
            else return ResponseMessege.JOINING_FAIL_ID;
        }

        if(!this.isCorrectForm(Password)) return ResponseMessege.JOINING_FAIL_PASSWORD;

        // join에 성공하는 경우(객체를 만들어 userList에 저장)

        User newMember=new User(ID, Password, true);
        userList.add(newMember);
        return ResponseMessege.JOINING_SUCCESS_USER;
    }

    // 로그인 기능을 담당하는 method
    public UserResult Login(String ID, String Password){

        ID=Capital2small(ID);

        // admin 계정으로 로그인 실패하는 경우 1. 비밀번호가 틀리는 경우, 2. 비활성화 상태(아이디를 만들지 않았거나 탈퇴한 상태)
        if(ID.equals("admin")){
            if(admin.CheckActivate()){
                if(Password.equals(admin.getPassword())) return new UserResult(admin, ResponseMessege.LOGIN_SUCCESS_ADMIN);
                else return new UserResult(nullUser, ResponseMessege.LOGIN_FAIL_PASSWORD);
            }
            else return new UserResult(nullUser, ResponseMessege.LOGIN_FAIL_ADMIN_NOT_EIXST);
        }

        User rUser=this.ID2User(ID);

        // 일반 계정으로 로그인 실패하는 경우 1. 존재하지 않는 ID인 경우, 2. ID는 존재하나 비밀번호가 매치되지 않는 경우, 3. 이미 탈퇴한 유저의 경우
        if(rUser==nullUser) return new UserResult(nullUser, ResponseMessege.LOGIN_FAIL_NOT_EIXST);
        else if(!rUser.getPassword().equals(Password)) return new UserResult(nullUser, ResponseMessege.LOGIN_FAIL_PASSWORD);

        if(!rUser.CheckActivate()) return new UserResult(nullUser, ResponseMessege.LOGIN_FAIL_LEAVE);

        // 로그인에 성공하는 경우 성공 메세지와 함께 ID를 통해 찾은 User 객체 반환하여 server에서 이용할 수 있도록 함.
        return new UserResult(rUser, ResponseMessege.LOGIN_SUCCESS_USER);
    }

    // 로그아웃 기능을 담당하는 method
    public String Logout(String ID, String Password, User user) {

        ID=Capital2small(ID);

        User checkUser=user;

        if((!checkUser.getID().equals(ID))||(!checkUser.getPassword().equals(Password))) return ResponseMessege.LOGOUT_FAIL_NOT_MATCH;
        else return ResponseMessege.LOGOUT_SUCCESS;

    }

    // 회원탈퇴 기능을 담당하는 method
    public String Leave(String ID, String Password) {

        // admin의 경우에는 static 변수에 저장해놓았으므로, 비활성화 과정을 따로 처리해야 함.
        if(ID.equals("admin")&&Password.equals(admin.getPassword())) {
            admin.DisabledAdmin();
            return ResponseMessege.LEAVE_SUCCESS_ADMIN;
        }

        ID=Capital2small(ID);
        User checkUser=this.ID2User(ID);

        // 탈퇴에 실패하는 경우 1. 가입된적이 없는 ID 입력, 2. ID와 맞지 않는 Password 입력, 3. 이미 탈퇴한 아이디 입력
        if(checkUser==nullUser) return ResponseMessege.LEAVE_FAIL_NOT_FOUND_ID;
        if(!checkUser.getPassword().equals(Password)) return ResponseMessege.LEAVE_FAIL_PASSWORD;

        if(!checkUser.CheckActivate()) return ResponseMessege.LEAVE_FAIL_ALREADY_LEFT;

        checkUser.setActivate(false);
        return ResponseMessege.LEAVE_SUCCESS;
    }

    // 회원복구 기능을 담당하는 method
    public String Recover(String ID, String Password) {

        ID=Capital2small(ID);

        User checkUser=this.ID2User(ID);

        // 복구에 실패하는 경우 1. 가입된적이 없는 ID 입력, 2. ID와 맞지 않는 Password 입력, 3. 활성화되어 사용되고 있는 아이디 입력
        if(checkUser==nullUser) return ResponseMessege.RECOVER_FAIL_NOT_FOUND_ID;
        if(!checkUser.getPassword().equals(Password)) return ResponseMessege.RECOVER_FAIL_PASSWORD;

        if(checkUser.CheckActivate()) return ResponseMessege.RECOVER_FAIL_ALREADY_ACTIVATE;

        checkUser.setActivate(true);
        return ResponseMessege.RECOVER_SUCCESS;


    }

}
