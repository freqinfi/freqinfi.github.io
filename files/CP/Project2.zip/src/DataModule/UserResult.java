package DataModule;

public class UserResult { // UserList의 Login method에서 User와 messege를 server에 동시에 전달하기 위해 설계한 객체

    private User currentUser;
    private String resultStr;

    public User getCurrentUser(){
        return this.currentUser;
    }

    public String getResultStr(){
        return this.resultStr;
    }

    public UserResult(User currentUser, String resultStr){

        this.currentUser=currentUser;
        this.resultStr=resultStr;

    }

}
