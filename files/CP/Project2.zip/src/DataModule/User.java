package DataModule;

import java.io.File;
import FileIO.*;

//HW4에서 사용한 User 객체 사용
public class User {

    // User마다 자기 자신의 검색로그를 저장하는 txt파일 저장, txt 파일 이름은 모든 User 동일하게 Mysearch.txt로 통일하였음.
    private final static String MYSEARCH_FILENAME = "Mysearch.txt";

    // User의 field 1. ID, 2. password
    // 3. User의 활성화 상태(가입 상태와 탈퇴 상태를 구분지음), 4. 자신의 검색정보를 txt파일에 write하는 FileWriter
    private String ID;
    private String password;
    private boolean isActivate;
    private MyFileWriter mySearch;

    public User(String ID, String password, boolean isActivate){

        this.ID=ID;
        this.password=password;
        this.isActivate=isActivate;

        String folderPath = UserManager.USERS_FOLDERPATH + File.separator + this.ID;
        if(!(this.ID==null))this.mySearch=new MyFileWriter(MYSEARCH_FILENAME, folderPath);

    }

    // ID get method
    public String getID(){
        return this.ID;
    }

    // Password get method
    public String getPassword(){
        return this.password;
    }

    // 활성화 상태를 반환하는 method(사실상 isActivate의 get method)
    public boolean CheckActivate() {return this.isActivate;}

    // isActivate의 set method
    public void setActivate(boolean isActivate) {
        this.isActivate=isActivate;
    }

    // Password의 set method
    public void setPassword(String password){
        this.password=password;
    }

    // load_data, load_fri에서 file을 읽어오기 위한 filePath를 반환하는 method
    public String getSearchListFilePath() {
        return this.mySearch.getFilePath();
    }

    // Mysearch 파일에 자신의 검색어를 저장하는 함수
    public void writeMykeyword(String Keyword) {
        this.mySearch.writeKeyword(Keyword, true);
    }

}