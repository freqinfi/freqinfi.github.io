package SearchModule;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import HTTPClientModule.HttpClient;
import java.util.LinkedList;
import java.net.URLEncoder;

public class SearchModule { // 검색 결과 가공하는 class

    public static LinkedList<String> searchResult(String query) {

        String encodedQuery=new String();
        try {
            encodedQuery=URLEncoder.encode(query, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        // HttpClient 객체에서 검색에 대한 정보를 JSON 형태로 이루어진 String 변수로 받아옴.

        String jsonStr=HttpClient.getInformation(encodedQuery);
        LinkedList<String> searchList=new LinkedList<>();

        // JsonStr을 Json 객체로 변환
        JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(jsonStr).getAsJsonObject();

        // Json 객체로 변환 후 parsing 과정 진행
        JsonObject queriesPart=jsonObject.getAsJsonObject("queries");
        JsonArray queries_request = queriesPart.getAsJsonArray("request");

        String searchTerms=queries_request.get(0).getAsJsonObject().get("searchTerms").getAsString();

        searchList.add("SearchTerms : " + searchTerms);

        JsonArray items_part = jsonObject.getAsJsonArray("items");

        // item 갯수에 따라서 searchList에 search item 저장
        if(items_part==null) {
            searchList.add("not existing search result");
            return searchList;
        }

        String totalResults=queries_request.get(0).getAsJsonObject().get("totalResults").getAsString();
        searchList.add("TotalResult : " + totalResults);

        // 첫번째 item 출력
        JsonObject item1=items_part.get(0).getAsJsonObject();
        String item1_title=item1.get("title").getAsString();
        String item1_link=item1.get("link").getAsString();
        searchList.add("\n");
        searchList.add("- First search result -");
        searchList.add("Title : " + item1_title);
        searchList.add("Link : " + item1_link);

        // item 하나만 있으면 return
        if(items_part.size()==1) return searchList;

        // 두번째 item 출력
        JsonObject item2=items_part.get(1).getAsJsonObject();
        String item2_title=item2.get("title").getAsString();
        String item2_link=item2.get("link").getAsString();
        searchList.add("\n");
        searchList.add("- Second search result -");
        searchList.add("Title : " + item2_title);
        searchList.add("Link : " + item2_link);

        // item 두 개만 있으면 return
        if(items_part.size()==2) return searchList;

        // 세번째 item 출력
        JsonObject item3=items_part.get(2).getAsJsonObject();
        String item3_title=item3.get("title").getAsString();
        String item3_link=item3.get("link").getAsString();
        searchList.add("\n");
        searchList.add("- Third search result -");
        searchList.add("Title : " + item3_title);
        searchList.add("Link : " + item3_link);

        return searchList;

    }

}
