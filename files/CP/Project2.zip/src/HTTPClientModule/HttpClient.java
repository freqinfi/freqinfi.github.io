package HTTPClientModule;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpClient {

    public static String getInformation(String query) {
        String apiKey = "AIzaSyD3GwhWYHN39_wbPLGGklOo7zPRRyQFKxs";
        String searchEngineId = "40e55ef4fd3184a21";
        String urlStr = "https://www.googleapis.com/customsearch/v1?key=" + apiKey + "&cx=" + searchEngineId + "&q=" + query;

        try {
            // Google API의 연결을 위한 URL 객체
            URL requestUrl = new URL(urlStr);

            // URL에서 연결을 주고 받는 객체
            HttpURLConnection connection = (HttpURLConnection) requestUrl.openConnection();

            connection.setRequestMethod("GET");

            // 요청을 보내고, 요청을 받는다.
            int responseCode = connection.getResponseCode();

            // 구글 API에서의 응답을 읽기 위한 BufferedReader
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // 구글과의 연결 끊기.
            connection.disconnect();

            // response를 JSON 형태로 SearchModule로 전달하기
            return new String(response);

        } catch (IOException e) {
            e.printStackTrace();
        }

        // 만약 연결을 하지 못했으면 null 반환
        return null;
    }
}
