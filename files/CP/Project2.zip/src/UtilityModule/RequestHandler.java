package UtilityModule;

import javax.xml.crypto.dsig.keyinfo.KeyValue;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.time.LocalDateTime;
import java.util.LinkedList;

public final class RequestHandler { //Utility class(여러 클래스에서 공유하는 method를 관리하는 class)

    // User 기능을 Request로 받았을 때, ID, Password를 추출하여 전달하는 method
    public static String[] Request2IDpassword(String request){

        String[] pairs = request.split("&");
        String[] MemberInfo = new String[2];

        int firstEM_id=pairs[0].indexOf('=');
        int firstEM_password=pairs[1].indexOf('=');

        String id=pairs[0].substring(firstEM_id+1);
        String password=pairs[1].substring(firstEM_password+1);

        if(id.equals("")||password.equals("")) return null;

        MemberInfo[0]=id;
        MemberInfo[1]=password;

        return MemberInfo;
    }

    // Search 기능(search, save_data에 대한 메서드에서 사용)을 Request로 받았을 때, 검색어를 추출하여 전달하는 method
    public static String Request2query(String request) {

        int firstEM=request.indexOf('=');
        int lastAM=0;
        for(int i=0;i<request.length();i++) {
            if(request.charAt(i)=='&') lastAM=i;
        }

        return request.substring(firstEM+1,lastAM);
    }

    // Query에서 search option을 txt에 저장하기 위한 메서드
    public static String SplitSearchOption(String query) {

        String[] SearchStr=query.split("\\?");
        if(SearchStr.length==1) return "";

        String searchOption=SearchStr[1];

        StringBuilder sb=new StringBuilder();
        sb.append("- Search Option :");

        String[] SearchOptionList=searchOption.split("&");
        int i=1;
        for(String s:SearchOptionList) {
            String[] type=s.split("=");
            sb.append(" ");
            sb.append(i++);
            sb.append(". ");
            sb.append(type[0]);
            sb.append(" (");
            sb.append(type[1]);
            sb.append(")");
        }
        return sb.toString();
    }

    // 검색어와 검색 옵션을 합쳐서 보낼 때 검색어만 추출하는 method(핫 keyword 저장을 위해서)
    public static String Query2SerachKey(String query) {

        String[] splitedStr = query.split("&");

        String[] SearchKeyStr=splitedStr[0].split("\\?");

        if(SearchKeyStr.length>=2) return SearchKeyStr[0].substring(0, SearchKeyStr[0].length()-1);
        else return SearchKeyStr[0];
    }

    public static String Request2freindID(String request) {

        String[] pairs = request.split("&");

        int firstEM_id=pairs[0].indexOf('=');

        String friendID=pairs[0].substring(firstEM_id+1);

        return friendID;
    }


    // filePath와 content, 덮어쓰기 여부를 전달받아 file에 content 한 줄을 써주는 methode
    // 전체 프로그램에서 모든 file 쓰는 method는 이 method를 경유하여 이용함.
    public static void writeFile(String filePath, String content, boolean append) {
        try {
            FileWriter writer = new FileWriter(filePath, append);
            writer.write(content);
            writer.write("\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 의도대로 split 되는지 확인용 메서드
    public static void printAll(String[] input){

        for(int i=0;i<input.length;i++) {
            System.out.println(input[i]);
        }

    }

    //이유는 모르겠지만 웹에서 맨 뒤에 공백문자가 포함됨. -> 나중에 원인 규명해서 고치기
    public static String StringList2String(LinkedList<String> StringList) {

        StringBuilder sb = new StringBuilder();
        for (String str : StringList) {
            sb.append(str);
            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }

    // txt 파일을 웹에 띄울 때 제목을 추가하는 메서드
    public static String addSubject(String subject, String content) {
        return subject+"\n\n"+content;
    }

    // 파일을 읽어서 String으로 전달하는 method(공백문자, 줄바꿈 포함해서 전송)
    public static String readFile(String filePath) {

        StringBuilder sb = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return sb.toString();
    }

    // load_log 기능에서 정보 히스토리에 시간 정보를 포함하기 위한 method
    public static String currentTime() {
        LocalDateTime currenTime = LocalDateTime.now();
        int hour = currenTime.getHour();
        int minute = currenTime.getMinute();
        int second = currenTime.getSecond();

        String formattedHour = String.format("%02d", hour);
        String formattedMinute = String.format("%02d", minute);
        String formattedSecond = String.format("%02d", second);

        return new String("[" + formattedHour + ":" + formattedMinute + ":" + formattedSecond + "]");
    }

}
