package UtilityModule;

public final class ResponseMessege { // response messege를 관리하는 class(final static field만 존재하므로, final class로 설정)

    public final static String PLEASE_ENTER_ALL_INFORMATION="You have not entered an ID or password.\nPlease enter all of them.";

    // 회원가입 관련 메세지
    public final static String JOINING_SUCCESS_ADMIN="Success joining as an administrator";
    public final static String JOINING_SUCCESS_USER="Success joining as an User";
    public final static String JOINING_FAIL_PASSWORD = "Password must be revised for right form\n\n" +
            "- Password must be at least 4 characters long and start with an alphabet\n" +
            "- Special symbols only allow @, #, %";
    public final static String JOINING_FAIL_ID="ID is already existing.\nPlease select other ID";
    public final static String JOINING_FAIL_ADMIN_EXISTING="Admin ID is already existing.\nPlease join as an User";
    public final static String JOINING_FAIL_LEAVE="This is the ID that left this program.\nPlease recover ID or use other ID";
    public final static String JOINING_FAIL_LOGINSTATE="Someone use this program\nJoining is only possible when no one is using it.";

    // 로그인 관련 메세지
    public final static String LOGIN_SUCCESS_ADMIN="Success login as an administrator";
    public final static String LOGIN_SUCCESS_USER="Success login as an User";
    public final static String LOGIN_FAIL_NOT_EIXST="User does not exist.";
    public final static String LOGIN_FAIL_ADMIN_NOT_EIXST="The administrator account is either not registered or has been left.\n" +
            "If you want to log in as an administrator, create or recover an administrator account.";
    public final static String LOGIN_FAIL_PASSWORD="You entered a different password.";
    public final static String LOGIN_FAIL_LEAVE="This is the ID that left this program.\nPlease recover ID or use other ID";
    public final static String LOGIN_FAIL_LOGINSTATE="Someone use this program\nLogin is only possible when no one is using it.";


    //로그아웃 관련 메세지
    public final static String LOGOUT_SUCCESS="Success logout";
    public final static String LOGOUT_FAIL_NOT_MATCH="ID and password are not match with current User";
    public final static String LOGOUT_FAIL_ANYONE_USING="No one is using the program.\nLogout can only possible when someone is logged in.";

    //탈퇴 관련 메세지
    public final static String LEAVE_SUCCESS="Your account have been successfully left.";
    public final static String LEAVE_SUCCESS_ADMIN="The administrator account has been successfully left.\n" +
            "You can recover the administrator account or rejoin with a different password.";
    public final static String LEAVE_FAIL_NOT_FOUND_ID = "The entered ID does not have any existing registration.";
    public final static String LEAVE_FAIL_PASSWORD = "The password does not match, so the leaving process was not completed.";
    public final static String LEAVE_FAIL_ALREADY_LEFT = "The ID has already been left.";
    public final static String LEAVE_FAIL_ANYONE_USING="No one is using the program.\nLeaving is only available when you are logged in.";


    //복구 관련 메세지
    public final static String RECOVER_SUCCESS="Success recover";
    public final static String RECOVER_FAIL_LOGINSTATE="Someone use this program\nRecovering is only possible when no one is using it.";
    public final static String RECOVER_FAIL_NOT_FOUND_ID = "The entered ID does not have any existing registration.";
    public final static String RECOVER_FAIL_PASSWORD = "The password does not match, so the recovering process was not completed.";
    public final static String RECOVER_FAIL_ALREADY_ACTIVATE = "The ID is already active.";

    // 검색 결과가 아직 없다는 메세지
    public final static String SEARCH_RESULTS_NOT_FOUND = "You have not saved any search terms yet.";
    public final static String SEARCH_RESULTS_FRIEND_NOT_FOUND = "Your friend has not saved any search terms yet.";

    // 해당 ID로 다른 User를 찾을 수 없다는 메세지, 자기 자신의 정보는 save_data 기능을 이용하라는 메세지
    public final static String NOT_FOUND_FRIEND = "We couldn't find a user with that ID.";
    public final static String ITS_YOUR_ID = "Please enter your friend's ID.\n If you want to know your own searchList, use load_data feature";

    // 기타 에러 메세지
    public final static String EMPTY_USER_LIST = "The user list is empty.";
    public final static String EMPTY_HOT_LIST = "The Hot List does not exist yet.";

    public final static String PLEASE_ENTER_QUERY = "Please enter your search query.";
    public final static String PLEASE_ENTER_FREIND_ID = "Please enter your freind ID.";
    public final static String ONLY_ADMIN_CAN_ACCESS = "Only administrator can access this option.\nIf you want to access, please login as admministrator.";
}
