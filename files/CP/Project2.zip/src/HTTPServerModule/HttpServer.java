package HTTPServerModule;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import DataModule.*;
import UtilityModule.*;
import FileIO.*;
import SearchModule.*;
import java.net.URLDecoder;

public class HttpServer {

    // SearchAPI의 이름을 가진 이 Program file 구조의 가장 상위 directory
    public final static String SEARCHAPI_FOLDERPATH = System.getProperty("user.dir") + File.separator + "SearchAPI";

    // 1. userManager : UserManager 객체 server에서 static으로 관리(하나만 생성)
    // 2. currentUser : 현재 프로그램에서 로그인되어있는 User 객체
    // 3. hotKeywordManager : HotKeywordManager 객체를 server에서 static으로 관리(하나만 생성)
    static UserManager userManager;
    static User currentUser;
    static HotKeywordManager hotKeywordManager;

    // while문을 이용하여 web에서 계속하여 응답을 받는 SearchAPI의 고유 main method(client와 server가 소통하는 장소)
    public static void main(String[] args) {

        int port = 8080;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server listening on port " + port);

            System.out.println("\nhttp://localhost:8080");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                // 웹에서 요청을 받기 위한 Thread 객체 선언
                Thread thread = new Thread(new ClientHandler(clientSocket));
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // program이 시작하기 위하여 static member initialize, 폴더 생성하는 method
    private static void ProgramStart() {

        File folder = new File(SEARCHAPI_FOLDERPATH);
        folder.mkdir();

        userManager = new UserManager();
        currentUser = UserManager.nullUser;
        hotKeywordManager = new HotKeywordManager();
    }

    //html 파일의 writer과 contentType, content 변수를 파라미터로 받아서 웹으로 적절한 응답을 보내기 위한 method
    private static void sendHttpResponse(PrintWriter out, String contentType, String content) {
        out.println("Content-Type: " + contentType);
        out.println("Content-Length: " + content.length());
        out.println();
        out.println(content);
    }

    private static class ClientHandler implements Runnable {

        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        // 웹에서 전달받은 request에 따라서 적절한 행동을 하는 method
        @Override
        public void run() {
            try {

                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true);


                String request = in.readLine();
                request = URLDecoder.decode(request, "UTF-8");

                // 중간에 공백이 생기는 부분을 구분하기 위해서 이를 사용하지 않기로 했음.
                //String[] requestParts = request.split(" ");

                // request를 세 가지 part로 나누는 부분
                LinkedList<Integer> spaceLocation = new LinkedList<>();

                for (int i = 0; i < request.length(); i++) {
                    if (request.charAt(i) == ' ') spaceLocation.add(i);
                }

                String[] requestParts = new String[3];

                requestParts[0] = request.substring(0, spaceLocation.getFirst());
                requestParts[1] = request.substring(spaceLocation.getFirst() + 1, spaceLocation.getLast());
                requestParts[2] = request.substring(spaceLocation.getLast() + 1);

                String path = requestParts[1];

                // CASE 1: It sends index.html page to the client. (server에서 web app에 접근하기 위한 링크 제공)
                if (path.equals("/")) {

                    String filePath = "src/index.html";
                    File file = new File(filePath);

                    if (file.exists() && file.isFile()) {
                        String contentType = Files.probeContentType(Paths.get(filePath));
                        String content = new String(Files.readAllBytes(Paths.get(filePath)));

                        // 프로그램을 시작
                        ProgramStart();

                        out.println("HTTP/1.1 200 OK");
                        sendHttpResponse(out, contentType, content);

                    } else {
                        // File not found
                        out.println("HTTP/1.1 404 Not Found");
                        out.println();
                    }

                }
                else if(path.equals("/favicon.ico")) {
                    // favico .ico 구문이 arrayIndexOutBoundsExeption을 부르기 때문에 따로 분류해둠.
                }
                else {  // CASE 2: It sends a specific data to the client as an HTTP Response.

                    String[] splitedCommand = path.split("/");
                    String content = new String();

                    // '/'를 기준으로 path String을 분류하고, 만약에 ID,비밀번호에 '/'가 존재하면 이를 처리함
                    if (splitedCommand.length > 6) {
                        String[] joinStr = new String[splitedCommand.length - 5];
                        for (int i = 5; i < splitedCommand.length; i++) {
                            joinStr[i - 5] = splitedCommand[i];
                        }
                        splitedCommand[5] = String.join("/", joinStr);
                    }

                    // User 기능(5가지 method)
                    if (splitedCommand[4].equals("user")) {

                        int LocationOfQM = splitedCommand[5].indexOf("?");

                        String reqKind = splitedCommand[5].substring(0, LocationOfQM);
                        String Info = splitedCommand[5].substring(LocationOfQM + 1);

                        String[] MemberInfo = RequestHandler.Request2IDpassword(Info);

                        if (MemberInfo == null) {
                            content = ResponseMessege.PLEASE_ENTER_ALL_INFORMATION;
                            out.println("HTTP/1.1 400 BAD Request");
                            sendHttpResponse(out, "text/plain", content);
                            throw new NotEnterInfoExeption();
                        }

                        String ID = MemberInfo[0];
                        String Password = MemberInfo[1];

                        if (reqKind.equals("join")) {

                            // Login 상태에서는 joining process를 진행할 수 없음
                            if (!(currentUser == UserManager.nullUser)) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.JOINING_FAIL_LOGINSTATE + "\nCurrent User : " + currentUser.getID();
                            } else {
                                content = userManager.Joining(ID, Password);

                                // 전달받은 메세지가 SUCCESS면 응답 코드 200 송신, 아니라면 응답 코드 400 송신
                                if (content == ResponseMessege.JOINING_SUCCESS_USER || content == ResponseMessege.JOINING_SUCCESS_ADMIN) {
                                    out.println("HTTP/1.1 200 OK");
                                } else out.println("HTTP/1.1 400 BAD Request");
                            }
                        } else if (reqKind.equals("login")) {

                            // Login 상태에서는 물론 login을 진행할 수 없음
                            if (!(currentUser == UserManager.nullUser)) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.LOGIN_FAIL_LOGINSTATE + "\nCurrent User : " + currentUser.getID();
                            } else {
                                UserResult userResult = userManager.Login(ID, Password);
                                content = userResult.getResultStr();

                                // 전달받은 User 객체가 nullUser이라면 응답 코드 400 송신, 아니라면 응답 코드 200 송신
                                if (userResult.getCurrentUser() == UserManager.nullUser)
                                    out.println("HTTP/1.1 400 BAD Request");
                                else {
                                    currentUser = userResult.getCurrentUser();
                                    out.println("HTTP/1.1 200 OK");
                                }
                            }
                        } else if (reqKind.equals("logout")) {

                            // Login 상태가 아닐 때 Logout을 진행할 수 없음
                            if (currentUser == UserManager.nullUser) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.LOGOUT_FAIL_ANYONE_USING;
                            } else {
                                content = userManager.Logout(ID, Password, currentUser);

                                // 전달받은 메세지가 SUCCESS면 응답 코드 200 송신, 아니라면 응답 코드 400 송신
                                if (content == ResponseMessege.LOGOUT_SUCCESS) {
                                    currentUser = UserManager.nullUser;
                                    out.println("HTTP/1.1 200 OK");
                                } else out.println("HTTP/1.1 400 BAD Request");
                            }
                        } else if (reqKind.equals("leave")) {

                            // 자신의 아이디로 로그인 된 상태에서만 탈퇴 가능(Login 상태가 아니면 응답 코드 400 송신)
                            if (currentUser == UserManager.nullUser) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.LEAVE_FAIL_ANYONE_USING;
                            } else {
                                content = userManager.Leave(ID, Password);

                                // 전달받은 메세지가 SUCCESS면 응답 코드 200 송신, 아니라면 응답 코드 400 송신
                                if (content == ResponseMessege.LEAVE_SUCCESS || content == ResponseMessege.LEAVE_SUCCESS_ADMIN) {
                                    currentUser = UserManager.nullUser;
                                    out.println("HTTP/1.1 200 OK");

                                } else out.println("HTTP/1.1 400 BAD Request");
                            }
                        } else if (reqKind.equals("recover")) {

                            // 아무도 로그인하지 않은 상태에서만 recover 사용 가능(로그인 상태인 경우 응답 코드 400 송신)
                            if (!(currentUser == UserManager.nullUser)) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.RECOVER_FAIL_LOGINSTATE + "\nCurrent User : " + currentUser.getID();
                            } else {
                                content = userManager.Recover(ID, Password);

                                // 전달받은 메세지가 SUCCESS면 응답 코드 200 송신, 아니라면 응답 코드 400 송신
                                if (content == ResponseMessege.RECOVER_SUCCESS) {
                                    out.println("HTTP/1.1 200 OK");

                                } else out.println("HTTP/1.1 400 BAD Request");
                            }
                        }
                        // 사용자 기능을 사용하고 나면 UserList의 수정 정보가 존재하므로, 이를 File에도 업데이트함.
                        UserManager.admin.updateUserListFile();
                    }
                    // Search 기능(5가지 method), 관리자 기능(2가지 method)
                    else if (splitedCommand[4].equals("data")) {

                        // path를 '?' 기준으로 분류하여 request의 종류와 search 정보를 분류한다.
                        int LocationOfQM = splitedCommand[5].indexOf("?");

                        String reqKind = splitedCommand[5].substring(0, LocationOfQM);
                        String searchInfo = splitedCommand[5].substring(LocationOfQM + 1);

                        if (reqKind.equals("search")) {

                            // query를 입력하지 않으면 에러 처리
                            String query = RequestHandler.Request2query(searchInfo);
                            if (query.equals("")) {
                                out.println("HTTP/1.1 400 OK");
                                content = ResponseMessege.PLEASE_ENTER_QUERY;
                            } else {
                                LinkedList<String> searchList = SearchModule.searchResult(query);
                                content = RequestHandler.StringList2String(searchList);
                                out.println("HTTP/1.1 200 OK");
                            }
                        } else if (reqKind.equals("save_data")) {

                            // query를 입력하지 않으면 에러처리
                            String query = RequestHandler.Request2query(searchInfo);
                            if (query.equals("")) {
                                out.println("HTTP/1.1 400 OK");
                                content = ResponseMessege.PLEASE_ENTER_QUERY;
                            } else {
                                String searchKey = RequestHandler.Query2SerachKey(query);
                                String searchOption = RequestHandler.SplitSearchOption(query);

                                currentUser.writeMykeyword(RequestHandler.currentTime());
                                currentUser.writeMykeyword("- Search Keyword : " + searchKey);
                                if (searchOption != "") {
                                    currentUser.writeMykeyword(searchOption);
                                }
                                currentUser.writeMykeyword("");

                                // 검색어만 저장하기 위하여 query 변수에 검색어만 추출하는 함수 사용
                                hotKeywordManager.updateAll(searchKey);

                                LinkedList<String> searchList = SearchModule.searchResult(query);
                                content = RequestHandler.StringList2String(searchList);

                                out.println("HTTP/1.1 200 OK");
                            }
                        } else if (reqKind.equals("load_data")) {

                            content = RequestHandler.readFile(currentUser.getSearchListFilePath());

                            // 아직까지 검색 결과가 없다면 응답코드 400 송신, 하나라도 존재한다면 응답코드 200 송신.
                            if (content.equals("")) {
                                content = ResponseMessege.SEARCH_RESULTS_NOT_FOUND;
                                out.println("HTTP/1.1 400 OK");
                            } else {
                                content = RequestHandler.addSubject("My Search List", content);
                                out.println("HTTP/1.1 200 OK");
                            }

                        } else if (reqKind.equals("load_fri")) {

                            String FriendID = RequestHandler.Request2freindID(searchInfo);

                            if (FriendID.equals("admin") && UserManager.admin.CheckActivate()) {

                                content = RequestHandler.readFile(UserManager.admin.getSearchListFilePath());
                                if(content.equals("")) {
                                    content=ResponseMessege.NOT_FOUND_FRIEND;
                                    out.println("HTTP/1.1 400 BAD Request");
                                }
                                else {
                                    content = RequestHandler.addSubject("Frind's Search List", content);
                                    out.println("HTTP/1.1 200 OK");
                                }

                            } else {
                                // 형변환 불가능하기 때문에 임시적으로 Usermanager의 admin 변수 사용하도록 의도하였음
                                User friend = UserManager.admin.getFriend(FriendID);

                                if (FriendID.equals("")) {
                                    out.println("HTTP/1.1 400 OK");
                                    content = ResponseMessege.PLEASE_ENTER_FREIND_ID;
                                } else {
                                    // 제공받은 ID로 friend를 찾을 수 없는 경우 응답 코드 400 송신
                                    if (friend == UserManager.nullUser) {
                                        content = ResponseMessege.NOT_FOUND_FRIEND;
                                        out.println("HTTP/1.1 400 BAD Request");
                                    } else if (friend.getID().equals(currentUser.getID())) {
                                        content = ResponseMessege.ITS_YOUR_ID;
                                        out.println("HTTP/1.1 400 BAD Request");
                                    } else {
                                        content = RequestHandler.readFile(friend.getSearchListFilePath());

                                        // 아직까지 검색 결과가 없다면 응답코드 400 송신, 하나라도 존재한다면 응답코드 200 송신.
                                        if (content.equals("")) {
                                            content = ResponseMessege.SEARCH_RESULTS_FRIEND_NOT_FOUND;
                                            out.println("HTTP/1.1 400 OK");
                                        } else {
                                            content = RequestHandler.addSubject("Frind's Search List", content);
                                            out.println("HTTP/1.1 200 OK");
                                        }
                                    }
                                }
                            }

                        } else if (reqKind.equals("load_hot")) {

                            // hotKeywordManager의 toString을 받는다.
                            content = hotKeywordManager.toString();

                            if (content.equals("")) {
                                out.println("HTTP/1.1 400 BAD Request");
                                content = ResponseMessege.EMPTY_HOT_LIST;
                            } else {
                                out.println("HTTP/1.1 200 OK");
                                content = RequestHandler.addSubject("Hot Search List", content);
                            }

                        } else if (reqKind.equals("load_acc")) {

                            // 만약 현재 admin이 아니라면 응답 코드 400 송신(웹에서도 막아두었지만 이중으로 차단하였음.)
                            if (!(currentUser == UserManager.admin)) {
                                content=ResponseMessege.ONLY_ADMIN_CAN_ACCESS;
                                out.println("HTTP/1.1 400 BAD Request");
                            } else {
                                // down casting 이용
                                content = ((Administrator) currentUser).IDList();

                                out.println("HTTP/1.1 200 OK");
                            }
                        } else if (reqKind.equals("load_log")) {

                            // 만약 현재 admin이 아니라면 응답 코드 400 송신(웹에서도 막아두었지만 이중으로 차단하였음.)
                            if (!(currentUser == UserManager.admin)) {
                                content=ResponseMessege.ONLY_ADMIN_CAN_ACCESS;
                                out.println("HTTP/1.1 400 BAD Request");
                            } else {
                                // Administrator에 쓰여진 History를 모두 복사하여 웹에 전시함
                                content = RequestHandler.readFile(UserManager.admin.getHistoryFilepath());
                                out.println("HTTP/1.1 200 OK");
                            }
                        }

                    }
                    sendHttpResponse(out, "text/plain", content);

                    //admin이 없을 때에도 저장해야 하기 때문에 admin 객체를 만들어 두어 처음부터 History를 모두 저장
                    UserManager.admin.saveHistory(RequestHandler.currentTime() + " [req]" + path);
                    System.out.println(currentUser.getID());

                }
                clientSocket.close();
            } catch (FileNotFoundException e) {
            } catch (IllegalArgumentException e){
            } catch (NotEnterInfoExeption e) {
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // 아이디, 비밀번호를 입력하지 않으면 에러처리
    static class NotEnterInfoExeption extends Exception {
    }
}