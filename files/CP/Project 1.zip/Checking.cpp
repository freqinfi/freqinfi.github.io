#include "Checking.h"

using namespace std;

Checking::Checking(int num, float bal, float min, float chg)
    :BankAccount(num, bal), minimum(min), charge(chg) {}

int Checking::withdraw(float amount) {
    if (this->bal <= amount) {
        cout << "Cannot withdraw $" << amount << " on account #" << this->acctnum << " because the balance is low" << endl;
        return 0;
    }
    else {
        if (this->bal < this->minimum) {
            this->bal -= charge;
        }
        this->bal -= amount;
        return 1;
    }
    return 0;
}

void Checking::print() {
    if (bal < 1000) this->credit = 1;
    else if (bal < 2000) this->credit = 2;
    else this->credit = 3;

    cout << "Checking Account: " << this->acctnum << endl;
    cout << "\tBankname: " << this->bank_name << endl;
    cout << "\tCredit: " << this->credit << endl;
    cout << "\tBalance: " << this->bal << endl;
    cout << "\tMinimum to Avoid Charges: " << this->minimum << endl;
    cout << "\tCharge per Check: " << this->charge << endl;
    cout << endl;
}


