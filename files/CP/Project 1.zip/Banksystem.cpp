#include "BankAccount.h"
#include "BankSystem.h"

using namespace std;

void BankSystem::transaction(BankAccount* from, BankAccount* to, float amount) {

    int newamount = amount;

    if (from->getBankname().compare(to->getBankname()) != 0) {
        newamount += TRANSACTION_FEE;
    }

    if (from->withdraw(newamount) == 0) return;

    to->deposit(amount);

}

void BankSystem::deposit(BankAccount* b, float amount) {
    b->deposit(amount);
}

void BankSystem::withdraw(BankAccount* b, float amount) {
    b->withdraw(amount);
}

void BankSystem::loan(BankAccount* b, float amount) {
    b->loan(amount);
}

