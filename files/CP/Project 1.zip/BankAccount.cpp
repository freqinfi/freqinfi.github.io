#include "BankAccount.h"

using namespace std;

BankAccount::BankAccount(int num, float bal) 
    :acctnum(num),bal(bal){

    if (bal < 1000) this->credit = 1;
    else if (bal < 2000) this->credit = 2;
    else this->credit = 3;

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<int> dis(0, 99);

    int conNum = dis(gen) % 3;
    if (conNum == 0) {
        this->bank_name = "�ϳ�";
    }
    else if (conNum == 1) {
        this->bank_name = "�츮";
    }
    else if (conNum == 2) {
        this->bank_name = "����";
    }

}

void BankAccount::deposit(float amount) {
    bal += amount;
}

int BankAccount::withdraw(float amount) {
    bal -= amount;
    return 1;
}

int BankAccount::getAcctnum() {
    return this->acctnum;
}

float BankAccount::getBalance() {
    return this->bal;
}

string BankAccount::getBankname() {
    return this->bank_name;
}

int BankAccount::getcredit() {
    return this->credit;
}

void BankAccount::loan(float amount) {

    if (bal < 1000) this->credit = 1;
    else if (bal < 2000) this->credit = 2;
    else this->credit = 3;

    if (this->credit == 1) {
        cout << "The amount cannot be loaned" << endl;
    }
    else if (this->credit == 2) {
        if (100 <= amount && amount <= 500) {
            bal += amount * 0.9;
        }
        else {
            cout << "The amount cannot be loaned" << endl;
        }
    }
    else if (this->credit == 3) {
        if (100 <= amount && amount <= 1000) {
            bal += amount * 0.95;
        }
        else {
            cout << "The amount cannot be loaned" << endl;
        }
    }
}