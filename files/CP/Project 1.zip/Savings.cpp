#include"Savings.h"

Savings::Savings(int num, float bal, float rate) :BankAccount(num, bal), intrate(rate) {}
void Savings::interest() {
    this->bal += this->bal * (intrate / 100 / 12);
}
int Savings::withdraw(float amount) {
    if (this->bal <= amount) {
        cout << "Cannot withdraw $" << amount << " on account #" << this->acctnum << " because the balance is low" << endl;
        return 0;
    }
    else {
        this->bal -= amount;
        return 1;
    }
    return 0;
}

void Savings::print() {
    if (bal < 1000) this->credit = 1;
    else if (bal < 2000) this->credit = 2;
    else this->credit = 3;

    cout << "Saving Account: " << this->acctnum << endl;
    cout << "\tBankname: " << this->bank_name << endl;
    cout << "\tCredit: " << this->credit << endl;
    cout << "\tBalance: " << this->bal << endl;
    cout << "\tinterest: " << this->intrate <<"%"<< endl;
    cout << endl;
}