#include"InterestChecking.h"

using namespace std;

InterestChecking::InterestChecking(int num, float bal, float cmin, float imin, float chg, float rate, float monchg)
    :Checking(num, bal, cmin, chg), intrate(rate), minint(imin), moncharge(monchg) {}



void InterestChecking::interest() {
    if (this->bal < minint) {
        this->bal -= moncharge;
    }
    else {
        this->bal += this->bal * (intrate / 100 / 12);
    }
}

void InterestChecking::print() {
    if (bal < 1000) this->credit = 1;
    else if (bal < 2000) this->credit = 2;
    else this->credit = 3;

    cout << "Interest Checking Account: " << this->acctnum << endl;
    cout << "\tBankname: " << this->bank_name << endl;
    cout << "\tCredit: " << this->credit << endl;
    cout << "\tBalance: " << this->bal << endl;
    cout << "\tMinimum to Avoid Charges: " << this->minimum << endl;
    cout << "\tCharge per Check: " << this->charge << endl;
    cout << "\tMinimum balance for getting interest and No Monthly Fee: " << this->minint << endl;
    cout << "\tinterest: " << this->intrate <<"%"<< endl;
    cout << "\tMonthly Fee: " << this->moncharge << endl;
    cout << endl;

}