clear, clc, close all


%% using calibration 

%Channel 

channel=readmatrix('Thermocouple.csv');

%3과 12를 각각 (2,4),(11,13)을 통하여 선형보간
channel(:,3)=(channel(:,2)+channel(:,4))/2;
channel(:,12)=(channel(:,11)+channel(:,13))/2;

channel=transpose(channel);
time=0:3:30;

figure;
plot(time,channel);
xlabel('Time(minute)');
ylabel('Temperature[\circC]');

Hue=readmatrix('Hue.xlsx');

%256보다 작은 Hue값 모두 256씩 상승
for i=1:190
    for j=1:63
        if Hue(i,j)<200
            Hue(i,j)=Hue(i,j)+256;
        end
    end
end

%각 행의 평균
Hue_mean=mean(transpose(Hue));
Hue_mean=transpose(Hue_mean);

%Hue의 1행이 channel 16, Hue의 190행이 channel 1/ 15개의 등간격으로 나눠서 반올림한 것이 channel
%위치이다. 이 위치를 Hue_mean에 넣어서 각 channel에 대응하는 hue값을 도출

hue_channel_location=linspace(190,1,16);
hue_channel_location=transpose(round(hue_channel_location));
hue_channel=Hue_mean(hue_channel_location);
temperature_channel=channel(:,11);

%선형회귀(3,12 제외하고 선형회귀)
hue_channel(3)=[];
hue_channel(12)=[];
temperature_channel(3)=[];
temperature_channel(12)=[];

%결정계수 계산
%mdl = fitlm(hue_channel,temperature_channel);
%mdl.Rsquared.Adjusted;

calibration=polyfit(hue_channel,temperature_channel,1);
calib = @(x) x*calibration(1)+calibration(2);


figure;
plot(hue_channel,temperature_channel,'ko');
hold on;
plot(220:300, calib(220:300),'r');
xlabel('Hue');
ylabel('Temperature[\circC]');

%calibration을 이용한 Fin의 온도분포
width_rangeC=linspace(0,100,63);
length_rangeC=linspace(0,270,190);
temp_through_Hue=calib(Hue);

%figure 1, 16개 열전대의 time-temperature curve
figure;
[Width_rangeC, Length_rangeC] = meshgrid(width_rangeC,length_rangeC);
mesh(Width_rangeC, Length_rangeC, temp_through_Hue);
xlabel("Width axis [mm]");
ylabel("Length axis [mm]");
zlabel("Temperature [\circC]");


%% using analytic solution

%물성치
rho=1.225;
nue=1.5*10^-5;
v=5;
width=0.1;
length=0.27;
depth=0.002;

Re=v*width/nue;
Pr=0.7;
Nusselt = 0.664 * Re^(1/2) * Pr^(1/3);
k_air = 26.2e-3;
k_copper=401;
%h값, T_base, T_infi
h = Nusselt * k_air / width;
P=2*width+2*depth;
Ac=width*depth;
T_infi=mean(channel(:,1));
T_base=channel(1,11);

m=sqrt(h*P/(k_copper*Ac));
x_anal=linspace(0,0.27,271);

%해석적 해의 함수(x에 대한 함수)
anal = @(x) T_infi+(T_base-T_infi)*(cosh(m*(length-x))+(h/(m*k_copper))*sinh(m*(length-x)))/(cosh(m*length)+(h/(m*k_copper))*sinh(m*length));

%1D->2D 온도분포를 똑같이 시각화 하기 위해
T_anal=transpose(anal(x_anal));
temp_through_anal=zeros(271,101);
for i=1:271
    temp_through_anal(i,:)=T_anal(i);
end

temp_through_anal=flipud(temp_through_anal);
width_rangeA=linspace(0,100,101);
length_rangeA=linspace(0,270,271);
[Width_rangeA, Length_rangeA] = meshgrid(width_rangeA,length_rangeA);

%2D 온도분포 도시
figure;
mesh(Width_rangeA, Length_rangeA, temp_through_anal);
xlabel("Width axis [mm]");
ylabel("Length axis [mm]");
zlabel("Temperature [\circC]");

%% using FDM

dx=0.002;
dy=0.002;
dz=0.002; %depth와 같은 방향


% T_base와 T_infi, h, k_copper 등은 해석적 해 구하는 과정에서 사용한 값 사용
% m,n 대신 s,t 사용

s=(width/dx) +1;
t=(length/dy) +1;

T_n=ones(s,t);
T_n=T_n*T_infi;
T_n(:,1)=T_base;
% T_n 설정하고, 1열은 base의 온도와 같게 둔다, 나머지 요소는 모두 T_infi와 같게 둔다.

errorMax=1e-7;
error=1;
iteration=0;
FDM_coef=h*depth/k_copper;

while error>errorMax

    T_old=T_n;
    %기존 온도 복사

    for i=2:1:s-1
        for j=2:1:t-1
            % internal(모서리, 꼭짓점 x) node 계산
            T_n(i,j)=((2*FDM_coef+4)^-1)*(T_old(i,j+1)+T_old(i,j-1)+T_old(i-1,j)+T_old(i+1,j)+T_infi*2*FDM_coef);
        end
    end

    % case 2 : i==1인 모서리 node 계산, case 3 : i==s인 모서리 node 계산
    for j=2:1:t-1
        T_n(1,j)=((2*FDM_coef+2)^-1)*(T_old(1+1,j)+0.5*(T_old(1,j-1)+T_old(1,j+1))+T_infi*2*FDM_coef);
        T_n(s,j)=((2*FDM_coef+2)^-1)*(T_old(s-1,j)+0.5*(T_old(s,j-1)+T_old(s,j+1))+T_infi*2*FDM_coef);
    end
    % case 4 : j==t인 모서리 node 계산
    for i=2:1:s-1
        T_n(i,t)=((2*FDM_coef+2)^-1)*(T_old(i,t-1)+0.5*(T_old(i-1,t)+T_old(i+1,t))+T_infi*2*FDM_coef);
    end
        
    % case 5 : 나머지 상단 두 꼭짓점 node 계산
    T_n(1,t)=((3*FDM_coef+2)^-1)*(T_old(1,t-1)+T_old(2,t)+3*T_infi*FDM_coef);
    T_n(s,t)=((3*FDM_coef+2)^-1)*(T_old(s-1,t)+T_old(s,t-1)+3*T_infi*FDM_coef);

    iteration=iteration+1;
    error=max(max(abs(T_n-T_old)));

end

% FDM 방법으로 얻은 fin의 온도 분포 T_n에 대해서 3차원 그래프 도시

figure
s_fdm=0:2:100;
t_fdm=0:2:270;
T_n=transpose(T_n);
T_n=flipud(T_n);

[S_FDM, T_FDM]=meshgrid(s_fdm,t_fdm);
mesh(S_FDM, T_FDM, T_n);
xlabel("Width axis [mm]");
ylabel("Length axis [mm]");
zlabel("Temperature [\circC]");

%% Comparison(width direction의 평균으로 2D comparison)

% 2차원 데이터를 평균시켜 1차원 데이터로 만드는 과정(T_anal은 이미 1D data, hue data는 이미 진행한 data 기반으로 생성)
% T_FDM은 1차원 데이터 새로 생성

x_anal=transpose(x_anal);
T_anal=flipud(T_anal);
temp_hue_mean=calib(Hue_mean);
x_huemean=transpose(linspace(0,270,190));

T_FDM_mean=mean(transpose(T_n));
T_FDM_mean=transpose(T_FDM_mean);
x_FDMmean=transpose(linspace(0,270,136));

% 1D 온도분포 3가지 비교하기 위하여 겹쳐서 도시
figure;

hold on;
plot(x_anal*1000,T_anal,'ko','MarkerSize',4);

plot(x_huemean,temp_hue_mean,'bo','MarkerSize',4);

plot(x_FDMmean,T_FDM_mean,'ro','MarkerSize',4);

xlabel("Length axis [mm]");
ylabel("Temperature [\circC]");
legend("Analytic", "Hue-value", "FDM", 'Location','southeast');


% 열전달량 계산을 위해 다시 원위치
T_n=flipud(T_n);
T_n=transpose(T_n);

%% total heat transfer

% 1. analytic method
q_coeff=(T_base-T_infi)*(h*P*k_copper*Ac)^0.5; %q값 계산에 이용하는 계수
qfin_anal=q_coeff*(tanh(m*length)+h/(m*k_copper))/(1+tanh(m*length)*h/(m*k_copper)); %qfin, using tanh

% 2. FDM method

%calculate convection q for each node 
qfin_FDM=zeros(51,136);

for i=2:1:s-1
    for j=2:1:t-1
        % internal(모서리, 꼭짓점 x) node 계산
        qfin_FDM(i,j)=2*h*depth^2*(T_n(i,j)-T_infi);
    end
end

% case 2 : i==1인 모서리 node 계산, case 3 : i==s인 모서리 node 계산
for j=2:1:t-1
    qfin_FDM(i,j)=2*h*depth^2*(T_n(i,j)-T_infi);
    qfin_FDM(i,j)=2*h*depth^2*(T_n(i,j)-T_infi);
end
% case 4 : j==t인 모서리 node 계산
for i=2:1:s-1
     qfin_FDM(i,j)=2*h*depth^2*(T_n(i,j)-T_infi);
end

qfin_FDM(1,t)=1.5*h*depth^2*(T_n(1,t)-T_infi);
qfin_FDM(s,t)=1.5*h*(depth^2)*(T_n(s,t)-T_infi);

%sum all q_FDM
qfin_FDM_value=sum(sum(qfin_FDM));

% 3. hue method
T_hue=flipud(temp_through_Hue);
T_hue=transpose(T_hue);


%calculate convection q for each node 
qfin_hue=zeros(63,190);
s_hue=63;
t_hue=190;
d_s=0.1/62;
d_t=0.27/189;

for i=2:1:s_hue-1
    for j=2:1:t_hue-1
        % internal(모서리, 꼭짓점 x) node 계산
        qfin_hue(i,j)=2*h*d_s*d_t*(T_hue(i,j)-T_infi);
    end
end

% case 2 : i==1인 모서리 node 계산, case 3 : i==s인 모서리 node 계산
for j=2:1:t_hue-1
    qfin_hue(i,j)=h*(d_t*depth+d_s*d_t)*(T_hue(i,j)-T_infi);
    qfin_hue(i,j)=h*(d_t*depth+d_s*d_t)*(T_hue(i,j)-T_infi);
end
% case 4 : j==t인 모서리 node 계산
for i=2:1:s_hue-1
     qfin_hue(i,j)=h*(d_s*depth+d_s*d_t)*(T_hue(i,j)-T_infi);
end

qfin_hue(1,t)=h*(0.5*(d_t+d_s)*depth+0.5*d_s*d_t)*(T_hue(1,t)-T_infi);
qfin_hue(s,t)=h*(0.5*(d_t+d_s)*depth+0.5*d_s*d_t)*(T_hue(s,t)-T_infi);

%sum all q_FDM
qfin_hue_value=sum(sum(qfin_hue));

%% validation for 1-D analysis

% FDM, Hue method에서 Length 방향의 평균 온도와 전체 평균 온도 얻기
T_wAvg_FDM=mean(transpose(T_n));
T_wAvg_hue=mean(temp_through_Hue);
T_tAvg_FDM=mean(T_wAvg_FDM);
T_tAvg_hue=mean(T_wAvg_hue);

T_wPor_FDM=T_wAvg_FDM/T_tAvg_FDM;
T_wPor_hue=T_wAvg_hue/T_tAvg_hue;

% 2개의 width 방향의 함수 plot
figure
hold on;

plot(0:2:100, T_wPor_FDM,'bo','MarkerSize',4);
plot(linspace(0,100,63), T_wPor_hue, 'ro','MarkerSize',4);

xlabel("Width axis [mm]");
ylabel("mean ratio");
legend("FDM", "Hue-value",'Location','southeast');


%% Fin effectiveness, Fin efficiency

theta_b=T_base-T_infi;
Af=2*width*length+2*length*depth+width*depth;

ef_anal=qfin_anal/(h*Ac*theta_b);
ef_FDM=qfin_FDM_value/(h*Ac*theta_b);
ef_hue=qfin_hue_value/(h*Ac*theta_b);

nf_anal=qfin_anal/(h*Af*theta_b);
nf_FDM=qfin_FDM_value/(h*Af*theta_b);
nf_hue=qfin_hue_value/(h*Af*theta_b);

%% 2차 회귀곡선 이용
calibration2=polyfit(hue_channel,temperature_channel,2);
calib2 = @(x) x.^2*calibration2(1)+x*calibration2(2)+calibration2(3);
temp_hue2_mean=calib2(Hue_mean);

figure;
plot(hue_channel,temperature_channel,'ko');
hold on;
plot(220:300, calib2(220:300),'r');
xlabel('Hue');
ylabel('Temperature[\circC]');


figure;
hold on;
plot(x_anal*1000,T_anal,'ko','MarkerSize',4);
plot(x_huemean,temp_hue_mean,'bo','MarkerSize',4);

plot(x_huemean,temp_hue2_mean,'go','MarkerSize',4);

plot(x_FDMmean,T_FDM_mean,'ro','MarkerSize',4);

xlabel("Length axis [mm]");
ylabel("Temperature [\circC]");
legend("Analytic","Hue-value(linear)", "Hue-value(quadratic)", "FDM", 'Location','southeast');

% 2차 회귀곡선을 이용한 열전달량 계산

qfin_hue2=zeros(63,190);
T_hue2=calib2(Hue);
T_hue2=flipud(T_hue2);
T_hue2=transpose(T_hue2);

for i=2:1:s_hue-1
    for j=2:1:t_hue-1
        % internal(모서리, 꼭짓점 x) node 계산
        qfin_hue2(i,j)=2*h*d_s*d_t*(T_hue2(i,j)-T_infi);
    end
end

% case 2 : i==1인 모서리 node 계산, case 3 : i==s인 모서리 node 계산
for j=2:1:t_hue-1
    qfin_hue2(i,j)=h*(d_t*depth+d_s*d_t)*(T_hue2(i,j)-T_infi);
    qfin_hue2(i,j)=h*(d_t*depth+d_s*d_t)*(T_hue2(i,j)-T_infi);
end
% case 4 : j==t인 모서리 node 계산
for i=2:1:s_hue-1
     qfin_hue2(i,j)=h*(d_s*depth+d_s*d_t)*(T_hue2(i,j)-T_infi);
end

qfin_hue2(1,t)=h*(0.5*(d_t+d_s)*depth+0.5*d_s*d_t)*(T_hue2(1,t)-T_infi);
qfin_hue2(s,t)=h*(0.5*(d_t+d_s)*depth+0.5*d_s*d_t)*(T_hue2(s,t)-T_infi);

%sum all q_FDM
qfin_hue2_value=sum(sum(qfin_hue2));
