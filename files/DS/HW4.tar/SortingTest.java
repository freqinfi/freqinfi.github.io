import java.io.*;
import java.util.*;

public class SortingTest
{
	public static void main(String args[])
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try
		{
			boolean isRandom = false;	// 입력받은 배열이 난수인가 아닌가?
			int[] value;	// 입력 받을 숫자들의 배열
			String nums = br.readLine();	// 첫 줄을 입력 받음
			if (nums.charAt(0) == 'r')
			{
				// 난수일 경우
				isRandom = true;	// 난수임을 표시

				String[] nums_arg = nums.split(" ");

				int numsize = Integer.parseInt(nums_arg[1]);	// 총 갯수
				int rminimum = Integer.parseInt(nums_arg[2]);	// 최소값
				int rmaximum = Integer.parseInt(nums_arg[3]);	// 최대값

				Random rand = new Random();	// 난수 인스턴스를 생성한다.

				value = new int[numsize];	// 배열을 생성한다.
				for (int i = 0; i < value.length; i++)	// 각각의 배열에 난수를 생성하여 대입
					value[i] = rand.nextInt(rmaximum - rminimum + 1) + rminimum;
			}
			else
			{
				// 난수가 아닐 경우
				int numsize = Integer.parseInt(nums);

				value = new int[numsize];	// 배열을 생성한다.
				for (int i = 0; i < value.length; i++)	// 한줄씩 입력받아 배열원소로 대입
					value[i] = Integer.parseInt(br.readLine());
			}

			// 숫자 입력을 다 받았으므로 정렬 방법을 받아 그에 맞는 정렬을 수행한다.
			while (true)
			{
				int[] newvalue = (int[])value.clone();	// 원래 값의 보호를 위해 복사본을 생성한다.
				char algo = ' ';

				if (args.length == 4) {
					return;
				}

				String command = args.length > 0 ? args[0] : br.readLine();

				if (args.length > 0) {
					args = new String[4];
				}

				long t = System.currentTimeMillis();
				switch (command.charAt(0))
				{
					case 'B':	// Bubble Sort
						newvalue = DoBubbleSort(newvalue);
						break;
					case 'I':	// Insertion Sort
						newvalue = DoInsertionSort(newvalue);
						break;
					case 'H':	// Heap Sort
						newvalue = DoHeapSort(newvalue);
						break;
					case 'M':	// Merge Sort
						newvalue = DoMergeSort(newvalue);
						break;
					case 'Q':	// Quick Sort
						newvalue = DoQuickSort(newvalue, false);
						break;
					case 'q':	// revised Quick Sort
						newvalue = DoQuickSort(newvalue, true);
						break;
					case 'R':	// Radix Sort
						newvalue = DoRadixSort(newvalue);
						break;
					case 'S':	// Search
						algo = DoSearch(newvalue);
						break;
					case 'X':
						return;	// 프로그램을 종료한다.
					default:
						throw new IOException("잘못된 정렬 방법을 입력했습니다.");
				}
				if (isRandom)
				{
					// 난수일 경우 수행시간을 출력한다.
					System.out.println((System.currentTimeMillis() - t) + " ms");
				}
				else
				{
					// 난수가 아닐 경우 정렬된 결과값을 출력한다.
					if (command.charAt(0) != 'S') {
						for (int i = 0; i < newvalue.length; i++) {
							System.out.println(newvalue[i]);
						}
					} else {
						System.out.println(algo);

					}
				}

			}
		}
		catch (IOException e)
		{
			System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
		}
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static char DoSearch(int[] value)
	{
		int arrSize=value.length;
		int max=0;
		//최대자리수 계산
		for(int i=0;i<arrSize;i++){
			if(Math.abs(value[i])>max) max=Math.abs(value[i]);
		}
		int numDigits=(int)Math.log10(max)+1;

		//radix sort를 사용하는 경우
		if(arrSize<200) return 'R';
		else if(arrSize<300) {
			if (numDigits <= 8) return 'R';
		}
		else if(arrSize<400) {
			if (numDigits <= 7) return 'R';
		}
		else if(arrSize<500) {
			if (numDigits <= 6) return 'R';
		}
		else if(arrSize<900) {
			if (numDigits <= 5) return 'R';
		}
		else if(arrSize<1200) {
			if (numDigits <= 4) return 'R';
		}
		else if(arrSize<1800) {
			if (numDigits <= 3) return 'R';
		}
		else if(arrSize<3300) {
			if (numDigits <= 2) return 'R';
		}
		else {
			if (numDigits == 1) return 'R';
		}

		//rebundancy
		double rebundancy=redundancy(value);

		//중복도가 매우 높은 경우
		if(rebundancy<=0.5) return 'M';

		//sortedPair
		double sortedPair=sortedPair(value);

		//I를 사용하는 경우
		if((arrSize<=3000&&sortedPair>90)) return 'I';
		else if (3000<arrSize&&arrSize<=10000&&sortedPair>(double)9*arrSize/7000+(double)603/7) return 'I';
		else if (arrSize>10000&&sortedPair>(double)(arrSize-10000)*0.7/40000+99) return 'I';

		//역순이거나 정렬쌍이 66.66% 이상일 때 M을 사용하는 것이 효율적임
		if(sortedPair<15||sortedPair>66.66) return 'M';

		return 'Q';
	}

	//supplementary report, 50000이상의 배열에서 Dosearch
	/*
	private static char DoSearch(int[] value)
	{

		int arrSize=value.length;

		//rebundancy
		double rebundancy=redundancy(value);

		//수정된 Q를 사용하는 경우
		if(rebundancy<=1.2) return 'q';

		//sortedPair
		double sortedPair=sortedPair(value);

		//I를 사용하는 경우
		if(sortedPair>100-5000/(double)arrSize) return 'I';

		//Q 대신 M을 사용하는 경우
		if(arrSize<10000000){
			if(sortedPair<7.2||sortedPair>61) return 'M';
		}
		else {
			if(sortedPair<9.3||sortedPair>65) return 'M';
		}

		return 'Q';
	}
	 */


	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoBubbleSort(int[] value)
	{
		for(int i=value.length - 1;i>=0;i--){
			for(int j=0 ; j <= i-1 ; j++){
				if(value[j]>value[j+1]) {
					int temp = value[j];
					value[j] = value[j + 1];
					value[j + 1] = temp;
				}
			}
		}
		return value;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoInsertionSort(int[] value)
	{
		for(int i=1;i<value.length;i++){
			for(int j=i;j>0;j--){
				if(value[j]<value[j-1]){
					int temp = value[j];
					value[j]=value[j-1];
					value[j-1]=temp;
				}else{
					break;
				}
			}
		}
		return value;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////

	//Heapsort class 내부에서 정렬 진행
	private static int[] DoHeapSort(int[] value)
	{
		HeapSort h = new HeapSort(value);
		h.buildMaxheap();
		h.DoHeapSort();
		value=h.getHeap();

		return value;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////

	//Mergesort class 내부에서 정렬 진행
	private static int[] DoMergeSort(int[] value) {
		MergeSort m= new MergeSort(value);
		m.DoMergeSort();
		return (m.A);
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////

	//Quicksort class 내부에서 정렬 진행
	private static int[] DoQuickSort(int[] value, boolean isRevised) {
		QuickSort q= new QuickSort(value);
		q.DoQuickSort(isRevised);
		return (q.value);
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////

	private static int[] DoRadixSort(int[] value){

		int arrSize=value.length;
		int arrSizeM=0;
		int arrSizeP=0;
		for(int i=0;i<arrSize;i++){
			if(value[i]<0) arrSizeM++;
		}
		if(arrSizeM==0) return RadixSortHelper(value);

		int[] Marr=new int[arrSizeM];
		int[] Parr=new int[arrSize-arrSizeM];

		int putM=0;
		int putP=0;
		for(int i=0;i<arrSize;i++){
			if(value[i]<0) Marr[putM++]=(-1)*value[i];
			else Parr[putP++]=value[i];
		}
		Marr=RadixSortHelper(Marr);
		Parr=RadixSortHelper(Parr);

		for(int i=arrSizeM-1;0<=i;i--){
			value[arrSizeM-1-i]=(-1)*Marr[i];
		}
		for(int i=arrSizeM;i<arrSize;i++){
			value[i]=Parr[i-arrSizeM];
		}
		return value;
	}


	private static int[] RadixSortHelper(int[] value){

		int arrSize=value.length;
		int[] cnt=new int[10], start=new int[10];
		int[] sortedArr=new int[arrSize];
		int max=-1;
		for(int i=0;i<arrSize;i++){
			if(value[i]>max) max=value[i];
		}
		int numDigits=(int)Math.log10(max)+1;
		for(int digit=1;digit<=numDigits;digit++){
			for(int d=0;d<=9;d++){
				cnt[d]=0;
			}
			for(int i=0;i<arrSize;i++){
				cnt[(int)(value[i]/Math.pow(10,digit-1)%10)]++;
			}
			start[0]=0;
			for(int d=1;d<=9;d++){
				start[d]=start[d-1]+cnt[d-1];
			}
			for(int i=0;i<arrSize;i++){
				sortedArr[start[(int)(value[i]/Math.pow(10,digit-1))%10]++]=value[i];
			}
			for(int i=0;i<arrSize;i++){
				value[i]=sortedArr[i];
			}
		}
		return value;
	}

	//중복된 원소가 얼마나 있는지 중복의 척도를 계산하는 함수(낮은 값일수록 중복이 많다.)
	private static double redundancy(int[] value){
		String value_str = "str";

		Hashtable<Integer, String> ht=new Hashtable<>();
		for(int i=0;i<value.length;i++){
			ht.put(value[i], value_str);
		}
		return (ht.size()/(double)100) / ((value.length)/(double)100)*100;
	}

	//정렬된 쌍의 비율을 계산하는 함수
	private static double sortedPair(int[] value) {
		int rValue = 0;
		for (int i = 0; i < value.length - 1; i++) {
			if (value[i] <= value[i + 1]) rValue += 1;
		}

		return (rValue/(double)100) / ((value.length - 1)/(double)100)*100;
	}
}

//책 quick sort, partition algorithm 참고 p.320
class QuickSort{

	public int[] value;

	public void swap(int num1, int num2){
		int temp=this.value[num1];
		this.value[num1]=this.value[num2];
		this.value[num2]=temp;
	}// 배열 num1과 num2에 있는 값을 변경시키는 함수

	public QuickSort(int[] value){
		this.value=value;
	}

	public void DoQuickSort(boolean isRevised) {
		quickSortHelper(0, value.length - 1, isRevised);
	}

	private void quickSortHelper(int p, int r, boolean isRevised) {
		if (p < r) {
			int q = partition(p, r, isRevised);
			quickSortHelper(p, q - 1, isRevised);
			quickSortHelper(q + 1, r, isRevised);
		}
	}

	private int partition(int p, int r, boolean isRevised) {

		int pivot_value = value[r];
		int i = p - 1, tmp;
		if(!isRevised){
			for (int j = p; j < r; j++) {
				if (value[j] < pivot_value) {
					i++;
					swap(i,j);
				}
			}
		}
		else {
			for (int j = p; j < r; j++) {
				if (value[j] < pivot_value||(value[j]==pivot_value&&j%2==0)) {
					i++;
					swap(i,j);
				}
			}
		}
		swap(r,i+1);
		return i + 1;
	}
}

//책 Heapsort, perculateDown 참고 p.321
class HeapSort{

	private int[] Heap;
	private int size;

	public HeapSort(int[] value){
		size= value.length;
		this.Heap = value;
	}//Heapsort의 생성자

	public int[] getHeap() {
		return Heap;
	}

	public void swap(int num1, int num2){
		int temp=this.Heap[num1];
		this.Heap[num1]=this.Heap[num2];
		this.Heap[num2]=temp;
	}

	//시간복잡도 theta(n)
	public void buildMaxheap(){
		if(Heap.length>1){
			for(int i=(Heap.length-2)/2;i>=0;i--){
				percolateDown(i,Heap.length-1);
			}
		}
	}//첫번째로 최대힙을 구성하는 알고리즘

	public void percolateDown(int i, int n){
		int child=2*i+1;
		int rightChild=2*i+2;
		if(child<=n){
			//더 값이 큰 자식의 index로 교체
			if((rightChild<=n)&&(Heap[child]<Heap[rightChild])){
				child=rightChild;
			}
			if(Heap[i]<Heap[child]){
				swap(i,child);
				// 재귀 호출
				percolateDown(child, n);
			}
		}


	}
	public void DoHeapSort(){
		for(int i=this.size-1;i>0;i--){
			swap(0,i);
			percolateDown(0,i-1);
		}
	}
}

//21년도 기출문제 참고하여 향상된 mergesort 구현, 책 merge 참고
class MergeSort{

	public int[] A;
	private int[] B;

	public MergeSort(int[] value){
		this.A=value;
		B=new int[A.length];
		for(int i=0;i<A.length;i++){
			B[i]=A[i];
		}
	}

	public void DoMergeSort(){
		mSort(0,this.A.length-1,this.A,this.B);
	}

	private void mSort(int p, int r, int[] A, int[] B){
		if(p<r){
			int q=(p+r)/2;
			mSort(p,q,B,A);
			mSort(q+1,r,B,A);
			merge(p,q,r,B,A);
		}
	}

	private void merge(int p, int q, int r, int[] C, int[] D){
		int i = p; int j = q+1; int t = p;
		while (i <= q && j <= r) {
			if (C[i] <= C[j])
				D[t++] = C[i++];
			else
				D[t++] = C[j++];
		}
		while (i <= q) {
			D[t++] = C[i++];
		}
		while (j <= r) {
			D[t++] = C[j++];
		}

	}
}