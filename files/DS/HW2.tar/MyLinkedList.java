import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyLinkedList<T extends Comparable<T>> implements ListInterface<T> {
    // dummy head
    Node<T> head;
    int numItems;

    public MyLinkedList() {
        head = new Node<T>(null);
    }

    public final Iterator<T> iterator() {
        return new MyLinkedListIterator<T>(this);
    }

    @Override
    public boolean isEmpty() {
        return head.getNext() == null;
    }

    @Override
    public int size() {
        return numItems;
    }

    @Override
    public T first() {
        return head.getNext().getItem();
    }

    @Override
    public void add(T item) {
        Node<T> last = head;
        while (last.getNext() != null) {
            last = last.getNext();
        }
        last.insertNext(item);
        numItems += 1;
    }

    @Override
    public void removeAll() {
        head.setNext(null);
    }

    public void sortedAdd(T item){
        if(numItems==0){
            this.add(item);
            numItems+=1;
        }
        else{
            Node<T> prev = head;
            Node<T> temp = head.getNext();
            if(temp!=null) {
                while (temp.getItem().compareTo(item) < 0) {
                    prev = prev.getNext();
                    temp = temp.getNext();
                    if (temp == null) {
                        break;
                    }
                }
            }
            Node<T> newnode = new Node<T>(item);
            prev.setNext(newnode);
            newnode.setNext(temp);
            numItems+=1;
        }
    }

    public boolean Find(T item){
        for(T t : this){
            if(t.equals(item)){
                return true;
            }
        }
        return false;
    }

    public T FindAndCopy(T item){
        for(T t : this){
            if(t.equals(item)){
                return t;
            }
        }
        return null;
    }

    public boolean Delete(T item){
        if(!this.Find(item)){
            return false;
        }
        else {
            Node<T> prev = head;
            Node<T> temp = head.getNext();
            while(temp.getItem().compareTo(item)!=0){
                prev=prev.getNext();
                temp=temp.getNext();
            }
            prev.removeNext();
            numItems-=1;
            return true;
        }
    }
}

class MyLinkedListIterator<T extends Comparable<T>> implements Iterator<T> {

    private MyLinkedList<T> list;
    private Node<T> curr;
    private Node<T> prev;

    public MyLinkedListIterator(MyLinkedList<T> list) {
        this.list = list;
        this.curr = list.head;
        this.prev = null;
    }

    @Override
    public boolean hasNext() {
        return curr.getNext() != null;
    }

    @Override
    public T next() {
        if (!hasNext())
            throw new NoSuchElementException();

        prev = curr;
        curr = curr.getNext();

        return curr.getItem();
    }

    @Override
    public void remove() {
        if (prev == null)
            throw new IllegalStateException("next() should be called first");
        if (curr == null)
            throw new NoSuchElementException();
        prev.removeNext();
        list.numItems -= 1;
        curr = prev;
        prev = null;
    }
}