import java.util.Iterator;
import java.util.NoSuchElementException;

public class MovieDB {

    private MyLinkedList<Genre> GenreList = null;

    public MovieDB() {
        GenreList = new MyLinkedList<Genre>();
    }

    public void insert(MovieDBItem item) {

        Genre Input_Genre = new Genre(item.getGenre());
        String Input_Movie = new String(item.getTitle());
        if(!this.GenreList.Find(Input_Genre)){
            this.GenreList.sortedAdd(Input_Genre);
        }

        Input_Genre = GenreList.FindAndCopy(Input_Genre);

        if(!Input_Genre.FindMovie(Input_Movie)){
            Input_Genre.sortedAddMovie(Input_Movie);
        }
    }

    public void delete(MovieDBItem item) {

        Genre Input_Genre = new Genre(item.getGenre());
        String Input_Movie = new String(item.getTitle());

        if(!this.GenreList.Find(Input_Genre)){
            System.out.println("no such movie");
        }
        else {
            Input_Genre = GenreList.FindAndCopy(Input_Genre);
            if(!Input_Genre.FindMovie(Input_Movie)){
                System.out.println("no such movie");
            }
            else {
                Input_Genre.DeleteMovie(Input_Movie);
                if(Input_Genre.getMovieList().isEmpty()){
                    GenreList.Delete(Input_Genre);
                }
            }
        }
    }

    public MyLinkedList<MovieDBItem> search(String term) {

        MyLinkedList<MovieDBItem> searchResult = new MyLinkedList<MovieDBItem>();

        for(Genre GenreIterator : this.GenreList){
            for(String MovieIterator : GenreIterator.getMovieList()){
                if(MovieIterator.contains(term)){
                    MovieDBItem temp = new MovieDBItem(GenreIterator.getItem(), MovieIterator);
                    searchResult.sortedAdd(temp);
                }
            }
        }
        return searchResult;
    }

    public MyLinkedList<MovieDBItem> items() {
        MyLinkedList<MovieDBItem> allItems = new MyLinkedList<MovieDBItem>();

        for(Genre GenreIterator : this.GenreList){
            for(String MovieIterator : GenreIterator.getMovieList()){
                MovieDBItem temp = new MovieDBItem(GenreIterator.getItem(), MovieIterator);
                allItems.sortedAdd(temp);
            }
        }
        return allItems;
    }
}

class Genre extends Node<String> implements Comparable<Genre> {

    private MyLinkedList<String> movieList = null;

    public Genre(String name) {
        super(name);
        movieList = new MyLinkedList<String>();
    }

    public void sortedAddMovie(String Movie_Name){
        this.movieList.sortedAdd(Movie_Name);
        return;
    }

    public boolean FindMovie(String Movie_Name){
        return this.movieList.Find(Movie_Name);
    }

    public boolean DeleteMovie(String Movie_Name){
        return this.movieList.Delete(Movie_Name);
    }

    public MyLinkedList<String> getMovieList(){
        return this.movieList;
    }


    @Override
    public int compareTo(Genre o) {
        return this.getItem().compareTo(o.getItem());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        if(this.getItem()==null){
            result*=prime;
        }
        else {
            result*=prime;
            result+=this.getItem().hashCode();
        }
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Genre other = (Genre) obj;
        return this.getItem().equals(other.getItem());
    }
}
