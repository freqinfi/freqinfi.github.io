public class Node<T extends Comparable<T>> {
    private T item;
    private Node<T> next;

    public Node(T obj) {
        this.item = obj;
        this.next = null;
    }

    public Node(T obj, Node<T> next) {
        this.item = obj;
        this.next = next;
    }

    public final T getItem() {
        return item;
    }

    public final void setItem(T item) {
        this.item = item;
    }

    public final void setNext(Node<T> next) {
        this.next = next;
    }

    public Node<T> getNext() {
        return this.next;
    }

    public final void insertNext(T obj) {
        Node NextNode = new Node(obj);
        Node temp=this.next;
        this.next=NextNode;
        NextNode.next=temp;
    }

    public final void removeNext() {
        if(this.next==null) return;
        Node temp=this.next;
        temp=temp.next;
        this.next=temp;
    }
}