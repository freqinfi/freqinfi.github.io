import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BigInteger {
    public static final String QUIT_COMMAND = "quit";
    public static final String MSG_INVALID_INPUT = "wrong input";
    public static final Pattern EXPRESSION_PATTERN = Pattern.compile("");

    private int[] numarr;
    private int arr_len;
    private int sign;

    public void Show_BI()
    {
        if(this.sign==+1) {
            System.out.print("+");
        }
        else {
            System.out.print("-");
        }
        for(int i=0;i<arr_len;i++)
        {
            System.out.print(numarr[i]);
        }
    }

    public BigInteger(int sign, int num)
    {
        this.sign = sign;
        this.arr_len = 1;
        this.numarr = new int[1];
        this.numarr[0] = num;
    }


    public BigInteger(int sign, int[] numarr)
    {
        this.sign=sign;

        int first_num_location=0;

        while(numarr[first_num_location]==0){
            first_num_location++;
            if(first_num_location==numarr.length - 1) {
                break;}
        }
        if(first_num_location == numarr.length - 1) {
            this.arr_len=1;
            this.numarr = new int[this.arr_len];
            this.numarr[0] = numarr[numarr.length - 1];
        }
        else {

            this.arr_len = numarr.length - first_num_location;
            this.numarr = new int[this.arr_len];

            for (int i = 0; i < this.arr_len; i++) {
                this.numarr[i] = numarr[first_num_location + i];
            }
        }
    }

    public BigInteger(String str)
    {
        int first_num_location=0;
        int end_num_location=0;
        for(int i=0;i<str.length();i++)
        {
            if(48<=str.charAt(i)&&str.charAt(i)<=57)
            {
                first_num_location=i;
                break;
            }
        }
        for(int i=first_num_location;i<str.length();i++)
        {
            if(str.charAt(i)==' ')
            {
                end_num_location=i-1;
                break;
            }
            if(i==str.length() - 1)
            {end_num_location=str.length() - 1;}
        }

        this.arr_len=end_num_location-first_num_location+1;
        this.numarr=new int[this.arr_len];
        for(int i=0;i<this.arr_len;i++)
        {
            numarr[i] = str.charAt(first_num_location + i) - 48;
        }

        this.sign=1;

        for(int i=0;i<first_num_location;i++)
        {
            if (str.charAt(i) == '-') {
                this.sign = -1;}
        }
    }

    private int AbsCompare(BigInteger big) {
        if (this.arr_len > big.arr_len) {
            return 1;
        } else if (this.arr_len < big.arr_len) {
            return -1;
        } else {
            for(int i=0;i<this.arr_len;i++)
            {
                if(this.numarr[i]> big.numarr[i])
                {return 1;}
                else if (this.numarr[i]<big.numarr[i]) {return -1;}
            }
        }
        return 0;
    }

    private BigInteger AbsAdd(BigInteger big)
    {
        if(this.AbsCompare(big)==-1)
        {
            return big.AbsAdd(this);
        }
        int[] temporary=new int[this.arr_len+1];
        int carry=0;
        int i=0;

        for(i=0;i< big.arr_len;i++)
        {
            if(this.numarr[this.arr_len-i-1]+big.numarr[big.arr_len-i-1]+carry>=10)
            {
                temporary[this.arr_len-i] = this.numarr[this.arr_len-i-1]+big.numarr[big.arr_len-i-1]+carry - 10;
                carry=1;
            }
            else
            {
                temporary[this.arr_len-i] = this.numarr[this.arr_len-i-1]+big.numarr[big.arr_len-i-1]+carry;
                carry=0;
            }
        }
        for(;i<this.arr_len;i++)
        {
            if(this.numarr[this.arr_len-i-1]+carry>=10)
            {
                temporary[this.arr_len-i] = this.numarr[this.arr_len-i-1]+carry - 10;
                carry=1;
            }
            else
            {
                temporary[this.arr_len-i] = this.numarr[this.arr_len-i-1]+carry;
                carry=0;
            }
        }
        temporary[0]=carry;
        return new BigInteger(1, temporary);
    }

    private BigInteger AbsSubtract(BigInteger big)
    {
        if(this.AbsCompare(big)==0)
        {
            return new BigInteger(1,0);
        }
        if(this.AbsCompare(big)==-1)
        {
            return big.AbsSubtract(this);
        }
        int[] temporary=new int[this.arr_len];
        int carry=0;
        int i=0;

        for(i=0;i< big.arr_len;i++)
        {
            if(this.numarr[this.arr_len-i-1]-big.numarr[big.arr_len-i-1]-carry<0)
            {
                temporary[this.arr_len-i-1] = this.numarr[this.arr_len-i-1]-big.numarr[big.arr_len-i-1]-carry + 10;
                carry=1;
            }
            else
            {
                temporary[this.arr_len-i-1] = this.numarr[this.arr_len-i-1]-big.numarr[big.arr_len-i-1]-carry;
                carry=0;
            }
        }
        for(;i<this.arr_len;i++)
        {
            if(this.numarr[this.arr_len-i-1]-carry<0)
            {
                temporary[this.arr_len-i-1] = this.numarr[this.arr_len-i-1]-carry + 10;
                carry=1;
            }
            else
            {
                temporary[this.arr_len-i-1] = this.numarr[this.arr_len-i-1]-carry;
                carry=0;
            }
        }
        return new BigInteger(1, temporary);
    }

    public BigInteger Add(BigInteger big)
    {
        if(this.sign==1&&big.sign==1)
        {
            return this.AbsAdd(big);
        }
        else if(this.sign==-1&&big.sign==-1)
        {
            BigInteger bi= this.AbsAdd(big);
            bi.sign=-1;
            return bi;
        }
        else
        {
            BigInteger temp = this.AbsSubtract(big);
            temp.sign=this.sign;
            if(this.AbsCompare(big)==-1){temp.sign*=-1;}
            return temp;
        }
    }

    public BigInteger Subtract(BigInteger big)
    {
        if((this.sign*big.sign) == 1)
        {
            BigInteger temp = this.AbsSubtract(big);
            temp.sign=this.sign;
            if(this.AbsCompare(big)==-1){temp.sign*=-1;}
            return temp;
        }
        else if(this.sign==-1&&big.sign==1){
            BigInteger bi= this.AbsAdd(big);
            bi.sign=-1;
            return bi;
        }
        else if((this.sign==1&&big.sign==-1))
        {
            return this.AbsAdd(big);
        }
        else
        {
            return new BigInteger(1,0);
        }
    }

    private BigInteger DigitMultiply(int digit_num, int digit)
    {
        int[] temp = new int[this.arr_len+digit+1];
        int carry=0;
        int units=0;
        int tens=0;

        for(int i=0; i<this.arr_len; i++)
        {
            int cal_location=this.arr_len - i;
            units=(digit_num*this.numarr[cal_location-1])%10;

            if(tens+units+carry>=10) {
                temp[cal_location]=tens+units+carry-10;
                carry=1;
            }
            else {
                temp[cal_location]=tens+units+carry;
                carry=0;
            }
            tens=(digit_num*this.numarr[cal_location-1])/10;
        }
        temp[0]=carry+tens;
        for(int j=0;j<digit;j++)
        {
            temp[this.arr_len+j+1]=0;
        }

        return new BigInteger(1, temp);
    }

    public BigInteger Multiply(BigInteger big)
    {
        BigInteger temp=new BigInteger(1,0);

        for(int i=0; i<big.arr_len;i++)
        {
            temp = temp.AbsAdd(this.DigitMultiply(big.numarr[big.arr_len-1-i], i));
        }
        temp.sign=this.sign*big.sign;

        return temp;
    }

    @Override
    public String toString()
    {
        if(this.arr_len==1&&this.numarr[0]==0)
        {
            return new String("0");
        }

        String str="";
        if(this.sign==-1)
        {
            str+='-';
        }
        for(int i=0;i<arr_len;i++)
        {
            str+=(char) (numarr[i] + 48);
        }
        return str;
    }

    static BigInteger evaluate(String input) throws IllegalArgumentException
    {
        boolean check=false;
        char operator = '?';
        int operator_location=0;
        for(int i=0;i<input.length();i++)
        {
            if(48<=input.charAt(i)&&input.charAt(i)<=57){check=true;}
            if(check==true&&42<=input.charAt(i)&&input.charAt(i)<=45)
            {
                operator=input.charAt(i);
                operator_location=i;
                break;
            }
        }
        BigInteger num1 = new BigInteger(input.substring(0,operator_location));
        BigInteger num2 = new BigInteger(input.substring(operator_location+1, input.length()));
        BigInteger result;

        if(operator=='+') {
            result = num1.Add(num2);}
        else if(operator=='-'){
            result = num1.Subtract(num2);}
        else if(operator=='*'){
            result = num1.Multiply(num2);}
        else{result=new BigInteger("Wrong input");};

        return result;
    }

    public static void main(String[] args) throws Exception
    {
        try (InputStreamReader isr = new InputStreamReader(System.in))
        {
            try (BufferedReader reader = new BufferedReader(isr))
            {
                boolean done = false;
                while (!done)
                {
                    String input = reader.readLine();

                    try
                    {
                        done = processInput(input);
                    }
                    catch (IllegalArgumentException e)
                    {
                        System.err.println(MSG_INVALID_INPUT);
                    }
                }
            }
        }
    }

    static boolean processInput(String input) throws IllegalArgumentException
    {
        boolean quit = isQuitCmd(input);

        if (quit)
        {
            return true;
        }
        else
        {
            BigInteger result = evaluate(input);
            System.out.println(result.toString());

            return false;
        }
    }

    static boolean isQuitCmd(String input)
    {
        return input.equalsIgnoreCase(QUIT_COMMAND);
    }
}

