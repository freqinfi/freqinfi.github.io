import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

//======================================================Don't modify below===============================================================//
enum PieceType {king, queen, bishop, knight, rook, pawn, none}
enum PlayerColor {black, white, none}

//Name:
//StudentID#:  
public class ChessBoard {
	private final JPanel gui = new JPanel(new BorderLayout(3, 3));
	private JPanel chessBoard;
	private JButton[][] chessBoardSquares = new JButton[8][8];
	private Piece[][] chessBoardStatus = new Piece[8][8];
	private ImageIcon[] pieceImage_b = new ImageIcon[7];
	private ImageIcon[] pieceImage_w = new ImageIcon[7];
	private JLabel message = new JLabel("Enter Reset to Start");

	ChessBoard(){
		initPieceImages();
		initBoardStatus();
		initializeGui();
	}
	
	public final void initBoardStatus(){
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++) chessBoardStatus[j][i] = new Piece();
		}
	}
	
	public final void initPieceImages(){
		pieceImage_b[0] = new ImageIcon(new ImageIcon("./img/king_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[1] = new ImageIcon(new ImageIcon("./img/queen_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[2] = new ImageIcon(new ImageIcon("./img/bishop_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[3] = new ImageIcon(new ImageIcon("./img/knight_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[4] = new ImageIcon(new ImageIcon("./img/rook_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[5] = new ImageIcon(new ImageIcon("./img/pawn_b.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_b[6] = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
		
		pieceImage_w[0] = new ImageIcon(new ImageIcon("./img/king_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[1] = new ImageIcon(new ImageIcon("./img/queen_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[2] = new ImageIcon(new ImageIcon("./img/bishop_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[3] = new ImageIcon(new ImageIcon("./img/knight_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[4] = new ImageIcon(new ImageIcon("./img/rook_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[5] = new ImageIcon(new ImageIcon("./img/pawn_w.png").getImage().getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH));
		pieceImage_w[6] = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
	}
	
	public ImageIcon getImageIcon(Piece piece){
		if(piece.color.equals(PlayerColor.black)){
			if(piece.type.equals(PieceType.king)) return pieceImage_b[0];
			else if(piece.type.equals(PieceType.queen)) return pieceImage_b[1];
			else if(piece.type.equals(PieceType.bishop)) return pieceImage_b[2];
			else if(piece.type.equals(PieceType.knight)) return pieceImage_b[3];
			else if(piece.type.equals(PieceType.rook)) return pieceImage_b[4];
			else if(piece.type.equals(PieceType.pawn)) return pieceImage_b[5];
			else return pieceImage_b[6];
		}
		else if(piece.color.equals(PlayerColor.white)){
			if(piece.type.equals(PieceType.king)) return pieceImage_w[0];
			else if(piece.type.equals(PieceType.queen)) return pieceImage_w[1];
			else if(piece.type.equals(PieceType.bishop)) return pieceImage_w[2];
			else if(piece.type.equals(PieceType.knight)) return pieceImage_w[3];
			else if(piece.type.equals(PieceType.rook)) return pieceImage_w[4];
			else if(piece.type.equals(PieceType.pawn)) return pieceImage_w[5];
			else return pieceImage_w[6];
		}
		else return pieceImage_w[6];
	}

	public final void initializeGui(){
		gui.setBorder(new EmptyBorder(5, 5, 5, 5));
	    JToolBar tools = new JToolBar();
	    tools.setFloatable(false);
	    gui.add(tools, BorderLayout.PAGE_START);
	    JButton startButton = new JButton("Reset");
	    startButton.addActionListener(new ActionListener(){
	    	public void actionPerformed(ActionEvent e){
	    		initiateBoard();
	    	}
	    });
	    
	    tools.add(startButton);
	    tools.addSeparator();
	    tools.add(message);

	    chessBoard = new JPanel(new GridLayout(0, 8));
	    chessBoard.setBorder(new LineBorder(Color.BLACK));
	    gui.add(chessBoard);
	    ImageIcon defaultIcon = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
	    Insets buttonMargin = new Insets(0,0,0,0);
	    for(int i=0; i<chessBoardSquares.length; i++) {
	        for (int j = 0; j < chessBoardSquares[i].length; j++) {
	        	JButton b = new JButton();
	        	b.addActionListener(new ButtonListener(i, j));
	            b.setMargin(buttonMargin);
	            b.setIcon(defaultIcon);
	            if((j % 2 == 1 && i % 2 == 1)|| (j % 2 == 0 && i % 2 == 0)) b.setBackground(Color.WHITE);
	            else b.setBackground(Color.gray);
	            b.setOpaque(true);
	            b.setBorderPainted(false);
	            chessBoardSquares[j][i] = b;
	        }
	    }

	    for (int i=0; i < 8; i++) {
	        for (int j=0; j < 8; j++) chessBoard.add(chessBoardSquares[j][i]);
	        
	    }
	}

	public final JComponent getGui() {
	    return gui;
	}
	
	public static void main(String[] args) {
	    Runnable r = new Runnable() {
	        @Override
	        public void run() {
	        	ChessBoard cb = new ChessBoard();
                JFrame f = new JFrame("Chess");
                f.add(cb.getGui());
                f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                f.setLocationByPlatform(true);
                f.setResizable(false);
                f.pack();
                f.setMinimumSize(f.getSize());
                f.setVisible(true);
            }
        };
        SwingUtilities.invokeLater(r);
	}
		
			//================================Utilize these functions========================================//	
	
	class Piece{
		PlayerColor color;
		PieceType type;
		
		Piece(){
			color = PlayerColor.none;
			type = PieceType.none;
		}
		Piece(PlayerColor color, PieceType type){
			this.color = color;
			this.type = type;
		}
	}

	class PieceInformation{
		public int x;
		public int y;
		public PieceType type;

		public PieceInformation(int x, int y, PieceType type){
			this.x=x;
			this.y=y;
			this.type=type;
		}
	}

	class PairInteger{
		public int x;
		public int y;

		public PairInteger(int x, int y){
			this.x=x;
			this.y=y;
		}

		@Override
		public String toString() {
			return "("+ x +", "+ y + ")";
		}
	}

	public void setIcon(int x, int y, Piece piece){
		chessBoardSquares[y][x].setIcon(getImageIcon(piece));
		chessBoardStatus[y][x] = piece;
	}
	
	public Piece getIcon(int x, int y){
		return chessBoardStatus[y][x];
	}
	
	public void markPosition(int x, int y){
		chessBoardSquares[y][x].setBackground(Color.pink);
	}
	
	public void unmarkPosition(int x, int y){
		if((y % 2 == 1 && x % 2 == 1)|| (y % 2 == 0 && x % 2 == 0)) chessBoardSquares[y][x].setBackground(Color.WHITE);
		else chessBoardSquares[y][x].setBackground(Color.gray);
	}
	
	public void setStatus(String inpt){
		message.setText(inpt);
	}
	
	public void initiateBoard(){
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++) setIcon(i, j, new Piece());
		}
		setIcon(0, 0, new Piece(PlayerColor.black, PieceType.rook));
		setIcon(0, 1, new Piece(PlayerColor.black, PieceType.knight));
		setIcon(0, 2, new Piece(PlayerColor.black, PieceType.bishop));
		setIcon(0, 3, new Piece(PlayerColor.black, PieceType.queen));
		setIcon(0, 4, new Piece(PlayerColor.black, PieceType.king));
		setIcon(0, 5, new Piece(PlayerColor.black, PieceType.bishop));
		setIcon(0, 6, new Piece(PlayerColor.black, PieceType.knight));
		setIcon(0, 7, new Piece(PlayerColor.black, PieceType.rook));
		for(int i=0;i<8;i++){
			setIcon(1, i, new Piece(PlayerColor.black, PieceType.pawn));
			setIcon(6, i, new Piece(PlayerColor.white, PieceType.pawn));
		}
		setIcon(7, 0, new Piece(PlayerColor.white, PieceType.rook));
		setIcon(7, 1, new Piece(PlayerColor.white, PieceType.knight));
		setIcon(7, 2, new Piece(PlayerColor.white, PieceType.bishop));
		setIcon(7, 3, new Piece(PlayerColor.white, PieceType.queen));
		setIcon(7, 4, new Piece(PlayerColor.white, PieceType.king));
		setIcon(7, 5, new Piece(PlayerColor.white, PieceType.bishop));
		setIcon(7, 6, new Piece(PlayerColor.white, PieceType.knight));
		setIcon(7, 7, new Piece(PlayerColor.white, PieceType.rook));
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++) unmarkPosition(i, j);
		}
		onInitiateBoard();
	}
//======================================================Don't modify above==============================================================//	


//======================================================Implement below=================================================================//		
enum MagicType {MARK, CHECK, CHECKMATE};

	private int selX, selY;
	private boolean check, checkmate, end;
	public final int leftBoundary = 0;
	public final int rightBoundary = 7;
	public final int topBoundary = 0;
	public final int bottomBoundary = 7;
	public final Piece emptyPiece = new Piece(PlayerColor.none, PieceType.none);
	public final int BLACKTURN = -1;
	public final int WHITETURN = 1;

	public boolean blackTurn = true;
	public boolean whiteTurn = false;
	public boolean isClick = false;

	//말 잡을 때, 자신의 위치를 기억하기 위해서
	public int currentX;
	public int currentY;

	//white king, black king의 위치 추적
	public int WKlocationX = 7;
	public int WKlocationY = 4;
	public int BKlocationX = 0;
	public int BKlocationY = 4;
	public boolean isKingClick=false;

	//rook, bishoop, queen이 move할 때 도움을 주는 함수
	public boolean mymarkPositionRBQ(int x, int y, int turnType){

		if(0<=x && x<=7 && 0<=y && y<=7){

			if(turnType==BLACKTURN){
				if(chessBoardStatus[y][x].color==PlayerColor.black){
					return false;
				}
				else if(chessBoardStatus[y][x].color==PlayerColor.white){
					markPosition(x, y);
					return false;
				}
				else{
					markPosition(x, y);
					return true;
				}
			}

			else if(turnType==WHITETURN){
				if(chessBoardStatus[y][x].color==PlayerColor.white){
					return false;
				}
				else if(chessBoardStatus[y][x].color==PlayerColor.black){
					markPosition(x, y);
					return false;
				}
				else{
					markPosition(x, y);
					return true;
				}
			}

		}
		return false;
	}

	//pawn, king, knight가 move할 때, 도움을 주는 함수
	public void mymarkPositionPKK(int x, int y, int turnType){
		if(0<=x && x<=7 && 0<=y && y<=7){

			if(turnType==BLACKTURN){
				if(chessBoardStatus[y][x].color==PlayerColor.black){
					return;
				}
				markPosition(x, y);
			}

			else if(turnType==WHITETURN){
				if(chessBoardStatus[y][x].color==PlayerColor.white){
					return;
				}
				markPosition(x, y);
			}
		}
	}

	//pawn이 move할 때, 도움을 주는 함수
	public void mymarkPositionP1(int x, int y, int turnType){
		if(0<=x && x<=7 && 0<=y && y<=7){

			if(turnType==BLACKTURN){
				if(chessBoardStatus[y][x].color==PlayerColor.none){
					markPosition(x, y);
				}
			}

			else if(turnType==WHITETURN){
				if(chessBoardStatus[y][x].color==PlayerColor.none){
					markPosition(x, y);
				}
			}
		}
	}

	//pawn이 move할 때, 도움을 주는 함수
	public void mymarkPositionP2(int x, int y, int turnType){
		if(0<=x && x<=7 && 0<=y && y<=7){

			if(turnType==BLACKTURN){
				if(chessBoardStatus[y][x].color==PlayerColor.white){
					markPosition(x, y);
				}
			}

			else if(turnType==WHITETURN){
				if(chessBoardStatus[y][x].color==PlayerColor.black){
					markPosition(x, y);
				}
			}
		}
	}

	class ButtonListener implements ActionListener{

		int x;
		int y;

		ButtonListener(int x, int y){
			this.x = x;
			this.y = y;
		}

		//버튼을 누르면 누구의 턴인지, 어떤 상태인지에 따라서 다르게 행동
		public void actionPerformed(ActionEvent e) {

			PieceType currentType = chessBoardStatus[y][x].type;
			PlayerColor currentColor = chessBoardStatus[y][x].color;

			if(blackTurn){

				if(!isClick){
					if(currentColor == PlayerColor.black)
					{
						if(pieceMove(x, y, BLACKTURN, currentType)) {
							isClick = true;
							if (currentType == PieceType.king) isKingClick = true;

							currentX = x;
							currentY = y;
						}
						else return;
					}
				}
				else{
					if(isClickfunction(x, y)){
						blackTurn = false;
						whiteTurn = true;
						if(isKingClick){
							BKlocationX=x;
							BKlocationY=y;
						}
						setStatus("WHITE's TURN");
						LinkedList<PieceInformation> attackList=Attacklist(BLACKTURN);
						if(!attackList.isEmpty()) {
							setStatus("WHITE's TURN/CHECK");
							if(isCheckmate(BLACKTURN, attackList)) setStatus("WHITE's TURN/CHECKMATE");
						}

						//attackList 확인하는 code
						if(!attackList.isEmpty()) {
							System.out.println("attacklist");
							for (PieceInformation p : attackList) {
								System.out.println("x좌표: " + p.x );
								System.out.println("y좌표: " + p.y );
							}
						}
					};
					isClick = false;
					isKingClick=false;
				}
				return;
			}

			if(whiteTurn){

				if(!isClick){
					if(currentColor == PlayerColor.white)
					{
						if(pieceMove(x, y, WHITETURN, currentType)) {
							;
							isClick = true;
							if (currentType == PieceType.king) isKingClick = true;

							currentX = x;
							currentY = y;
						}
						else return;
					}
				}
				else{
					if(isClickfunction(x, y)){
						blackTurn = true;
						whiteTurn = false;
						if(isKingClick){
							WKlocationX=x;
							WKlocationY=y;
						}
						setStatus("BLACK's TURN");
						LinkedList<PieceInformation> attackList=Attacklist(WHITETURN);
						if(!attackList.isEmpty()){
							setStatus("BLACK's TURN/CHECK");
							if(isCheckmate(WHITETURN, attackList)) setStatus("BLACK's TURN/CHECKMATE");
						}

						//attackList 확인하는 code
						if(!attackList.isEmpty()) {
							System.out.println("attacklist");
							for (PieceInformation p : attackList) {
								System.out.println("x좌표: " + p.x );
								System.out.println("y좌표: " + p.y );
							}
						}
					};
					isClick = false;
					isKingClick=false;
				}
				return;
			}
		}

	}

	//어떤 말을 클릭했을 때 pink가 된 곳으로 이동할 수 있도록 만들어둔 함수
	public boolean isClickfunction(int x, int y){

		boolean isPink = chessBoardSquares[y][x].getBackground()==Color.pink;

		for(int i=0; i<8; i++){
			for(int j=0; j<8; j++){
				unmarkPosition(i, j);
			}
		}

		if(isPink) {

			chessBoardStatus[y][x] = chessBoardStatus[currentY][currentX];
			chessBoardStatus[currentY][currentX] = emptyPiece;
			setIcon(x, y, chessBoardStatus[y][x]);
			setIcon(currentX, currentY, chessBoardStatus[currentY][currentX]);
			return true;

		}
		return false;
	}

	//말이 move하는 것을 통제하는 함수
	public boolean pieceMove(int x, int y, int turnType, PieceType currentType){

		if(currentType==PieceType.pawn) pawnMove(x,y,turnType);
		else if(currentType==PieceType.knight) knightMove(x,y,turnType);
		else if(currentType==PieceType.rook) rookMove(x,y,turnType);
		else if(currentType==PieceType.bishop) bishopMove(x,y,turnType);
		else if(currentType==PieceType.queen) queenMove(x,y,turnType);
		else if(currentType==PieceType.king) kingMove(x,y,turnType);

		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				if(chessBoardSquares[j][i].getBackground()==Color.pink){
					return true;
				}
			}
		}
		return false;
	}

	//모든 말의 움직임을 규칙에 따라 구현해둔 것들
	public void pawnMove(int x, int y, int turnType) {

		switch (turnType) {
			case WHITETURN: {
				if (x == 6) {
					mymarkPositionP1(x-1, y, turnType);
					if(chessBoardStatus[y][x-1].color==PlayerColor.none) {
						mymarkPositionP1(x - 2, y, turnType);
					}
				} else {
					mymarkPositionP1(x-1, y, turnType);
				}
				mymarkPositionP2(x-1,y-1,turnType);
				mymarkPositionP2(x-1,y+1,turnType);
				return;
			}

			case BLACKTURN: {
				if (x == 1) {
					mymarkPositionP1(x + 1, y, turnType);
					if(chessBoardStatus[y][x+1].color==PlayerColor.none) {
						mymarkPositionP1(x + 2, y, turnType);
					}
				} else {
					mymarkPositionP1(x + 1, y, turnType);
				}
				mymarkPositionP2(x + 1, y - 1, turnType);
				mymarkPositionP2(x + 1, y + 1, turnType);
				return;
			}

		}
	}

	public void knightMove(int x, int y, int turnType){

		mymarkPositionPKK(x+2, y+1, turnType); mymarkPositionPKK(x+2, y-1, turnType);
		mymarkPositionPKK(x+1, y+2, turnType); mymarkPositionPKK(x+1, y-2, turnType);
		mymarkPositionPKK(x-1, y+2, turnType); mymarkPositionPKK(x-1, y-2, turnType);
		mymarkPositionPKK(x-2, y+1, turnType); mymarkPositionPKK(x-2, y-1, turnType);

	}

	public void rookMove(int x, int y, int turnType){

		int x_direction = 0;
		int y_direction = 0;

		while(mymarkPositionRBQ(x + x_direction + 1, y, turnType)){
			x_direction+=1;
		}
		x_direction = 0;
		while(mymarkPositionRBQ(x + x_direction - 1, y, turnType)){
			x_direction-=1;
		}
		while(mymarkPositionRBQ(x , y + y_direction + 1, turnType)){
			y_direction+=1;
		}
		y_direction = 0;
		while(mymarkPositionRBQ(x, y + y_direction - 1, turnType)){
			y_direction-=1;
		}
	}

	public void bishopMove(int x, int y, int turnType){

		int shift = 0;

		while(mymarkPositionRBQ(x + shift + 1, y + shift + 1, turnType)){
			shift+=1;
		}
		shift=0;
		while(mymarkPositionRBQ(x + shift + 1, y - shift - 1, turnType)){
			shift+=1;
		}
		shift=0;
		while(mymarkPositionRBQ(x - shift - 1, y + shift + 1, turnType)){
			shift+=1;
		}
		shift=0;
		while(mymarkPositionRBQ(x - shift - 1, y - shift - 1, turnType)){
			shift+=1;
		}
	}

	public void queenMove(int x, int y, int turnType){

		rookMove(x, y, turnType);
		bishopMove(x, y, turnType);

	}

	public void kingMove(int x, int y, int turnType){

		for(int i=-1;i<2;i++){
			for(int j=-1;j<2;j++){
				mymarkPositionPKK(x+i,y+j, turnType);
			}
		}

	}

	public boolean isCheckHelper(int x, int y, int turnType, PieceType desiredPiece){

		if(0<=x && x<=7 && 0<=y && y<=7){

			Piece currentPiece=getIcon(x,y);
			if(turnType==BLACKTURN&&!(currentPiece.color==PlayerColor.black)) return false;
			if(turnType==WHITETURN&&!(currentPiece.color==PlayerColor.white)) return false;
			if(currentPiece.type==desiredPiece) return true;
		}
		return false;
	}

	public boolean isCheckShiftHelper(int x, int y){

		if(0<=x && x<=7 && 0<=y && y<=7){
			if(getIcon(x,y).type==PieceType.none) return true;
		}
		return false;
	}

	public boolean KingCatch=false;
	//catch or occupy하는 함수
	public boolean isCatchOccupy(PairInteger pair, int turnType, boolean Catch){

		//어떤 자리를 상대편 말이 잡거나 점령할 수 있는지 확인하는 함수

		int Kx=pair.x;
		int Ky=pair.y;

		if(turnType==BLACKTURN) {

			//pawn이 잡을 수 있는지?
			if(Catch){
				if (isCheckHelper(Kx - 1, Ky - 1, turnType, PieceType.pawn)) return true;
				if (isCheckHelper(Kx - 1, Ky + 1, turnType, PieceType.pawn)) return true;
			}
			else {
				if (isCheckHelper(Kx - 1, Ky, turnType, PieceType.pawn)) return true;
				if (Kx==6){
					if (isCheckHelper(Kx - 2, Ky, turnType, PieceType.pawn)) return true;

				}
			}
		}
		else if(turnType==WHITETURN){

			//pawn이 잡을 수 있는지?
			if(Catch) {
				if (isCheckHelper(Kx + 1, Ky - 1, turnType, PieceType.pawn)) return true;
				if (isCheckHelper(Kx + 1, Ky + 1, turnType, PieceType.pawn)) return true;
			}
			else {
				if (isCheckHelper(Kx + 1, Ky, turnType, PieceType.pawn)) return true;
				if (Kx==1){
					if (isCheckHelper(Kx + 2, Ky, turnType, PieceType.pawn)) return true;

				}
			}
		}

		//비숍, 퀸, 룩이 잡을 수 있는지?
		int shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky)) shift++;
		if (isCheckHelper(Kx + shift, Ky, turnType, PieceType.rook)) return true;
		if (isCheckHelper(Kx + shift, Ky, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky)) shift++;
		if (isCheckHelper(Kx - shift, Ky, turnType, PieceType.rook)) return true;
		if (isCheckHelper(Kx - shift, Ky, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx, Ky + shift)) shift++;
		if (isCheckHelper(Kx, Ky + shift, turnType, PieceType.rook)) return true;
		if (isCheckHelper(Kx, Ky + shift, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx, Ky - shift)) shift++;
		if (isCheckHelper(Kx, Ky - shift, turnType, PieceType.rook)) return true;
		if (isCheckHelper(Kx, Ky - shift, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky + shift)) shift++;
		if (isCheckHelper(Kx + shift, Ky + shift, turnType, PieceType.bishop)) return true;
		if (isCheckHelper(Kx + shift, Ky + shift, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky - shift)) shift++;
		if (isCheckHelper(Kx + shift, Ky - shift, turnType, PieceType.bishop)) return true;
		if (isCheckHelper(Kx + shift, Ky - shift, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky + shift)) shift++;
		if (isCheckHelper(Kx - shift, Ky + shift, turnType, PieceType.bishop)) return true;
		if (isCheckHelper(Kx - shift, Ky + shift, turnType, PieceType.queen)) return true;

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky - shift)) shift++;
		if (isCheckHelper(Kx - shift, Ky - shift, turnType, PieceType.bishop)) return true;
		if (isCheckHelper(Kx - shift, Ky - shift, turnType, PieceType.queen)) return true;

		//나이트가 잡을 수 있는지?
		if (isCheckHelper(Kx + 2, Ky + 1, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx + 2, Ky - 1, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx - 2, Ky + 1, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx - 2, Ky - 1, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx + 1, Ky + 2, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx + 1, Ky - 2, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx - 1, Ky + 2, turnType, PieceType.knight)) return true;
		if (isCheckHelper(Kx - 1, Ky - 2, turnType, PieceType.knight)) return true;

		//king이 잡을 수 있는지? 점령은 무조건할 수 있기 때문에 배제해야함.
		if(Catch) {
			for (int i = -1; i < 2; i++) {
				for (int j = -1; j < 2; j++) {
					if (isCheckHelper(Kx + i, Ky + j, turnType, PieceType.king)) {
						KingCatch=true;
						return true;
					}
				}
			}
		}

		return false;
	}

	public LinkedList<PieceInformation> Attacklist(int turnType){
		//king의 위치를 계속 저장해둬서 특정할 때의 king을 위협하고 있는 말이 있는지 확인할 수 있음.
		//white king이 체크상태인지 확인

		LinkedList<PieceInformation> list=new LinkedList<>();

		int Kx=0;
		int Ky=0;

		if(turnType==BLACKTURN) {
			Kx = WKlocationX;
			Ky = WKlocationY;

			//king의 위치로부터 pawn이 king을 위협할 수 있는지 확인하는 code
			if(isCheckHelper(Kx-1,Ky-1,turnType, PieceType.pawn)) list.add(new PieceInformation(Kx-1,Ky-1,PieceType.pawn));
			if(isCheckHelper(Kx-1,Ky+1,turnType, PieceType.pawn)) list.add(new PieceInformation(Kx-1,Ky+1,PieceType.pawn));
		}
		else if(turnType==WHITETURN){
			Kx = BKlocationX;
			Ky = BKlocationY;

			//king의 위치로부터 pawn이 king을 위협할 수 있는지 확인하는 code
			if(isCheckHelper(Kx+1,Ky-1,turnType, PieceType.pawn)) list.add(new PieceInformation(Kx+1,Ky-1,PieceType.pawn));
			if(isCheckHelper(Kx+1,Ky+1,turnType, PieceType.pawn)) list.add(new PieceInformation(Kx+1,Ky+1,PieceType.pawn));
		}

		//king의 위치로부터 bishop, rook, queen이 king을 위협할 수 있는지 확인하는 code 부분
		int shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky)) shift++;
		if (isCheckHelper(Kx + shift, Ky, turnType, PieceType.rook)) list.add(new PieceInformation(Kx+shift,Ky,PieceType.rook));
		if (isCheckHelper(Kx + shift, Ky, turnType, PieceType.queen)) list.add(new PieceInformation(Kx+shift,Ky,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky)) shift++;
		if (isCheckHelper(Kx - shift, Ky, turnType, PieceType.rook)) list.add(new PieceInformation(Kx-shift,Ky,PieceType.rook));
		if (isCheckHelper(Kx - shift, Ky, turnType, PieceType.queen)) list.add(new PieceInformation(Kx-shift,Ky,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx, Ky + shift)) shift++;
		if (isCheckHelper(Kx, Ky + shift, turnType, PieceType.rook)) list.add(new PieceInformation(Kx,Ky+shift,PieceType.rook));
		if (isCheckHelper(Kx, Ky + shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx,Ky+shift,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx, Ky - shift)) shift++;
		if (isCheckHelper(Kx, Ky - shift, turnType, PieceType.rook)) list.add(new PieceInformation(Kx,Ky-shift,PieceType.rook));
		if (isCheckHelper(Kx, Ky - shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx,Ky-shift,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky + shift)) shift++;
		if (isCheckHelper(Kx + shift, Ky + shift, turnType, PieceType.bishop)) list.add(new PieceInformation(Kx+shift,Ky+shift,PieceType.rook));
		if (isCheckHelper(Kx + shift, Ky + shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx+shift,Ky+shift,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx + shift, Ky - shift)) shift++;
		if (isCheckHelper(Kx + shift, Ky - shift, turnType, PieceType.bishop)) list.add(new PieceInformation(Kx+shift,Ky-shift,PieceType.rook));
		if (isCheckHelper(Kx + shift, Ky - shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx+shift,Ky-shift,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky + shift)) shift++;
		if (isCheckHelper(Kx - shift, Ky + shift, turnType, PieceType.bishop)) list.add(new PieceInformation(Kx-shift,Ky+shift,PieceType.rook));
		if (isCheckHelper(Kx - shift, Ky + shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx-shift,Ky+shift,PieceType.queen));

		shift = 1;
		while (isCheckShiftHelper(Kx - shift, Ky - shift)) shift++;
		if (isCheckHelper(Kx - shift, Ky - shift, turnType, PieceType.bishop)) list.add(new PieceInformation(Kx-shift,Ky-shift,PieceType.rook));
		if (isCheckHelper(Kx - shift, Ky - shift, turnType, PieceType.queen)) list.add(new PieceInformation(Kx-shift,Ky-shift,PieceType.queen));

		//king의 위치로부터 knight가 king을 위협할 수 있는지 확인하는 code 부분
		if (isCheckHelper(Kx + 2, Ky + 1, turnType, PieceType.knight)) list.add(new PieceInformation(Kx+2,Ky+1,PieceType.knight));
		if (isCheckHelper(Kx + 2, Ky - 1, turnType, PieceType.knight)) list.add(new PieceInformation(Kx+2,Ky-1,PieceType.knight));
		if (isCheckHelper(Kx - 2, Ky + 1, turnType, PieceType.knight)) list.add(new PieceInformation(Kx-2,Ky+1,PieceType.knight));
		if (isCheckHelper(Kx - 2, Ky - 1, turnType, PieceType.knight)) list.add(new PieceInformation(Kx-2,Ky-1,PieceType.knight));
		if (isCheckHelper(Kx + 1, Ky + 2, turnType, PieceType.knight)) list.add(new PieceInformation(Kx+1,Ky+2,PieceType.knight));
		if (isCheckHelper(Kx + 1, Ky - 2, turnType, PieceType.knight)) list.add(new PieceInformation(Kx+1,Ky-2,PieceType.knight));
		if (isCheckHelper(Kx - 1, Ky + 2, turnType, PieceType.knight)) list.add(new PieceInformation(Kx-1,Ky+2,PieceType.knight));
		if (isCheckHelper(Kx - 1, Ky - 2, turnType, PieceType.knight)) list.add(new PieceInformation(Kx-1,Ky-2,PieceType.knight));

		//king의 위치로부터 black king이 king을 위협할 수 있는지 확인하는 code
		for (int i = -1; i < 2; i++) {
			for (int j = -1; j < 2; j++) {
				if (isCheckHelper(Kx + i, Ky + j, turnType, PieceType.king)) list.add(new PieceInformation(Kx + i,Ky + j,PieceType.king));
			}
		}

		return list;
	}

	public boolean isCheckmate(int turnType, LinkedList<PieceInformation> attackList){

		int Kx=0;
		int Ky=0;
		PlayerColor ally=PlayerColor.none;

		if(turnType==BLACKTURN){
			Kx=WKlocationX;
			Ky=WKlocationY;
			ally=PlayerColor.white;
		}
		else if(turnType==WHITETURN){
			Kx=BKlocationX;
			Ky=BKlocationY;
			ally=PlayerColor.black;
		}
		boolean xr = true;

		//왕을 옮기지 않아도 check에서 벗어날 수 있는 경우
		if(attackList.size()==1){
			PieceInformation attackPiece=attackList.getFirst();
			PieceType currenttype=attackPiece.type;
			int Cx=attackPiece.x;
			int Cy=attackPiece.y;


			if(isCatchOccupy(new PairInteger(Cx,Cy),turnType*(-1),true))
			{
				if(!KingCatch) return false;
				else KingCatch=false;
			}

			if(currenttype==PieceType.queen||currenttype==PieceType.rook||currenttype==PieceType.bishop) {
				LinkedList<PairInteger> betweenList=betweenPairList(Cx,Cy,Kx,Ky);
				for(PairInteger p:betweenList){
					if(isCatchOccupy(p,turnType*(-1), false)) return false;
				}
			}
		}

		LinkedList<PairInteger> movableKing=new LinkedList<>();

		//king이 피할 수 있는 자리를 모두 반환
		for (int i = -1; i < 2; i++) {
			for (int j = -1; j < 2; j++) {

				if(i==0&&j==0) continue;

				if(0<=Kx+i && Kx+i<=7 && 0<=Ky+j && Ky+j<=7) {
					if(!(chessBoardStatus[Ky+j][Kx+i].color==ally)){
						movableKing.add(new PairInteger(Kx+i,Ky+j));
					}
				}
			}
		}

		boolean rBoolean=true;
		//king이 피했을 때 그곳은 check가 아닌지 확인하기
		for(PairInteger p: movableKing){

			//나중에 삭제하기
			System.out.println(p.toString());

			Piece temp=chessBoardStatus[p.y][p.x];
			chessBoardStatus[p.y][p.x]=chessBoardStatus[Ky][Kx];
			chessBoardStatus[Ky][Kx].type=PieceType.none;
			chessBoardStatus[Ky][Kx].color=PlayerColor.none;

			if(!isCatchOccupy(p, turnType, true)) rBoolean=false;

			chessBoardStatus[Ky][Kx].type=PieceType.king;
			chessBoardStatus[Ky][Kx].color=ally;
			chessBoardStatus[p.y][p.x]=temp;

			if(!rBoolean) return false;
		}

		return true;
	}

	public LinkedList<PairInteger> betweenPairList(int Cx, int Cy, int Kx, int Ky){

		LinkedList<PairInteger> rList=new LinkedList<>();

		// 대각선으로 위치한 경우
		if(Cx!=Kx&&Cy!=Ky){

			if(Cx<Kx&&Cy<Ky){
				int shift=1;
				while(Cx+shift<Kx){
					rList.add(new PairInteger(Cx+shift,Cy+shift));
					shift++;
				}
			}

			else if(Cx<Kx&&Cy>Ky){
				int shift=1;
				while(Cx+shift<Kx){
					rList.add(new PairInteger(Cx+shift,Cy-shift));
					shift++;
				}
			}

			else if(Cx>Kx&&Cy<Ky){
				int shift=1;
				while(Cx-shift>Kx){
					rList.add(new PairInteger(Cx-shift,Cy+shift));
					shift++;
				}
			}

			else {
				int shift=1;
				while(Cx-shift>Kx){
					rList.add(new PairInteger(Cx-shift,Cy-shift));
					shift++;
				}
			}



		}
		// 직선으로 위치한 경우
		else {
			if(Cx==Kx){
				if(Cy>Ky){
					int y=Ky+1;
					while(y<Cy) {
						rList.add(new PairInteger(Cx,y));
						y++;
					}
				}
				else {
					int y=Cy+1;
					while(y<Cy) {
						rList.add(new PairInteger(Cx,y));
						y++;
					}
				}
			}
			else if (Cy==Ky) {
				if(Cx>Kx){
					int x=Kx+1;
					while(x<Cx) {
						rList.add(new PairInteger(x,Cy));
						x++;
					}
				}
				else {
					int x=Cx+1;
					while(x<Kx) {
						rList.add(new PairInteger(x,Cy));
						x++;
					}
				}

			}
		}

		for(PairInteger p:rList){
			System.out.println(p.toString());
		}
		System.out.println();

		return rList;
	}

	void onInitiateBoard(){

		setStatus("BLACK's TURN");

		//Turn 초기화
		this.blackTurn = true;
		this.whiteTurn = false;
		this.isClick = false;

		//king 위치 초기화
		this.WKlocationX = 7;
		this.WKlocationY = 4;
		this.BKlocationX = 0;
		this.BKlocationY = 4;
		this.isKingClick=false;

	}
}
