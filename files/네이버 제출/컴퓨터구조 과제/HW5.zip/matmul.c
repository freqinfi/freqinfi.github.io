#include <immintrin.h>
#include <stdlib.h>
#include "matmul.h"

#define BLOCK_SIZE 1024

#define UNROLL_SIZE 8
#pragma GCC target ("avx,avx2")

void matmul(const int M, const int N, const int K, const int *inputA, const int *inputB, int *output) {

    for (int k = 0; k < K; k += BLOCK_SIZE) {
    
        for (int i = 0; i < M; i++) {
            for (int block_k = k; block_k < k + BLOCK_SIZE; block_k++) {
                for (int j = 0; j < N; j += UNROLL_SIZE) {
                    
                    __m256i vec1 = _mm256_set1_epi32(inputA[i * K + block_k]);
                    __m256i vec2 = _mm256_loadu_si256((__m256i*)&inputB[block_k * N + j]);
                    __m256i curr = _mm256_loadu_si256((__m256i*)&output[i * N + j]);

                    curr = _mm256_add_epi32(curr, _mm256_mullo_epi32(vec1, vec2));

                    _mm256_storeu_si256((__m256i*)&output[i * N + j], curr);
                }
            }
        }
    }
}