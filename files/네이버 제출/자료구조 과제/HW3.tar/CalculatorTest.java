import java.io.*;
import java.util.Stack;

class WrongFomulaExeption extends RuntimeException{}
class CantCalculateExeption extends RuntimeException{}

public class CalculatorTest {
    public static int Operator_Priority(char Operator) {
        if (Operator == '^') {
            return 1;
        } else if (Operator == '~') {
            return 2;
        } else if (Operator == '*' || Operator == '/' || Operator == '%') {
            return 3;
        } else if (Operator == '+' || Operator == '-') {
            return 4;
        } else if (Operator == ',') {
            return 5;
        } else if (Operator == '(' || Operator == ')') {
            return 100;
        } else {
            return -1;
        }

    }

    public static boolean isDigit(char ch) {
        if (ch >= 48 && ch <= 57) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isOperator(char ch) {
        String Operator = new String("-^~/%*+");
        for(int i=0;i<Operator.length();i++){
            if(ch==Operator.charAt(i)){
                return true;
            }
        }return false;
    }

    public static void main(String args[]) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            try {
                String input = br.readLine();
                if (input.compareTo("q") == 0)
                    break;

                command(input);
            } catch (Exception e) {
                System.out.println("ERROR");
            }
        }
    }

    private static void command(String input) {
        long result = Calculate_ResultStack(input);
        System.out.println(result);
    }

    private static long Calculate_ResultStack(String input_str) throws WrongFomulaExeption {

        Stack<Character> OperatorStack = new Stack<>();
        StringBuilder MakeNumber = new StringBuilder();
        Stack<String> ResultStack = new Stack<>();

        char Current;
        boolean Digit_Ended = false;
        int Current_priority, Top_priority;
        int Parenthesis_Opend = 0;
        int avg_num = 0;

        for (int i = 0; i < input_str.length(); i++) {
            Current = input_str.charAt(i);

            if (Current != '\t' && Current != ' ') {

                //숫자 처리하는 코드
                if (isDigit(Current)) {
                    if (Digit_Ended) {
                        throw new WrongFomulaExeption();
                    }
                    MakeNumber.append(Current);
                    if (i+1==input_str.length()) {
                        ResultStack.push(new String(MakeNumber));
                        MakeNumber.setLength(0);
                        Digit_Ended = true;
                    } else {
                        if(isDigit(input_str.charAt(i + 1))){
                            continue;
                        }else {
                            ResultStack.push(new String(MakeNumber));
                            MakeNumber.setLength(0);
                            Digit_Ended = true;
                        }
                    }
                }
                //문자 처리하는 코드
                else if (isOperator(Current)) {

                    if (!Digit_Ended) {
                        if (Current == '-') {
                            Current = '~';
                        } else {
                            throw new WrongFomulaExeption();
                        }
                    }

                    Current_priority = Operator_Priority(Current);
                    while (!OperatorStack.isEmpty()) {
                        Top_priority = Operator_Priority(OperatorStack.peek());
                        //우선순위 같으면 안 빼내는 연산자들
                        if (Current == '^' || Current == '~') {
                            if (Top_priority < Current_priority) {
                                ResultStack.push(OperatorStack.pop().toString());
                            } else {
                                break;
                            }
                            //우선순위 같으면 빼내는 연산자들
                        } else {
                            if (Top_priority <= Current_priority) {
                                ResultStack.push(OperatorStack.pop().toString());
                            } else {
                                break;
                            }
                        }
                    }
                    OperatorStack.push(Current);
                    Digit_Ended = false;
                } else if (Current == '(') {
                    OperatorStack.push(Current);
                    Parenthesis_Opend++;
                } else if (Current == ')') {
                    if (Parenthesis_Opend <= 0||!Digit_Ended) {
                        throw new WrongFomulaExeption();
                    }
                    while (OperatorStack.peek() != '(') {
                        if(OperatorStack.peek()==',') {
                            avg_num++;
                            OperatorStack.pop();
                            continue;
                        }
                        ResultStack.push(OperatorStack.pop().toString());
                    }
                    if(avg_num!=0){
                        ResultStack.push(new String(Integer.toString(avg_num + 1)+" avg"));
                        avg_num=0;
                    }
                    OperatorStack.pop();
                    Parenthesis_Opend--;
                } else if (Current == ',') {
                    if(Parenthesis_Opend<=0||!Digit_Ended) {
                        throw new WrongFomulaExeption();
                    }
                    while (OperatorStack.peek() !=','&& OperatorStack.peek() != '('){
                        ResultStack.push(OperatorStack.pop().toString());
                    }
                    OperatorStack.push(Current);
                    Digit_Ended=false;
                } else {
                    throw new WrongFomulaExeption();
                }
            }
        }
        if (Parenthesis_Opend != 0) {
            throw new WrongFomulaExeption();
        }

        while (!OperatorStack.isEmpty()) {
            ResultStack.push(OperatorStack.pop().toString());
        }
        StringBuilder resultStr = new StringBuilder();

        for(int i=0;i<ResultStack.size() - 1;i++){
            resultStr.append(ResultStack.get(i)+" ");
        }
        resultStr.append(ResultStack.get(ResultStack.size()-1));

        Stack<Long> NumStack = new Stack<>();
        Stack<String> ResultStack_reverse = new Stack<>();
        String Current_str;
        char Firstletter_Current_str;
        long temp_result = 0;
        while (!ResultStack.isEmpty()) {
            ResultStack_reverse.push(ResultStack.pop());
        }

        while (!ResultStack_reverse.isEmpty()) {
            Current_str = ResultStack_reverse.peek();
            Firstletter_Current_str = Current_str.charAt(0);
            if (!isOperator(Firstletter_Current_str)) {
                //avg와 숫자 구별
                boolean isLong = true;
                for(int i=0;i<Current_str.length();i++){
                    if(Current_str.charAt(i)=='a') isLong=false;
                }
                //avg와 숫자인 것에 따라 다른 수행
                if(!isLong){
                    int spaceLocation = 0;
                    while(Current_str.charAt(++spaceLocation)!=' '){}
                    int num_opperand=Integer.parseInt(Current_str.substring(0,spaceLocation));
                    long[] opperands = new long[num_opperand];
                    for(int i=0;i<num_opperand;i++){
                        if(!NumStack.isEmpty()) opperands[i]=NumStack.pop();
                        else throw new WrongFomulaExeption();
                    }
                    temp_result=Calculate_average(opperands, num_opperand);
                    NumStack.push(temp_result);
                    ResultStack_reverse.pop();
                } else NumStack.push(string2long(ResultStack_reverse.pop()));
            } else if (Firstletter_Current_str == '~') {
                ResultStack_reverse.pop();
                temp_result = Calculate_unary(Firstletter_Current_str, NumStack.pop());
                NumStack.push(temp_result);
            } else {
                ResultStack_reverse.pop();
                temp_result = Calculate_binary(Firstletter_Current_str, NumStack.pop(), NumStack.pop());
                NumStack.push(temp_result);
            }
        }
        System.out.println(resultStr);
        return NumStack.peek();
    }

    private static long string2long(String num_str) {
        long temp = 0;
        int sizeof_numstr = num_str.length();
        for (int i = 0; i < sizeof_numstr; i++) {
            int digit = num_str.charAt(sizeof_numstr - 1 - i) - 48;
            for (int j = 0; j < i; j++) {
                digit *= 10;
            }
            temp += digit;
        }
        return temp;
    }

    private static long Calculate_binary(char Operator, long Opperand2, long Opperand1) throws CantCalculateExeption {
        if (Operator == '^') {
            if (Opperand2 < 0) {
                throw new CantCalculateExeption();
            } else {
                return (long) Math.pow(Opperand1, Opperand2);
            }
        } else if (Operator == '*') {
            return Opperand1 * Opperand2;
        } else if (Operator == '/') {
            if (Opperand2 == 0) {
                throw new CantCalculateExeption();
            } else {
                return Opperand1 / Opperand2;
            }
        } else if (Operator == '%') {
            if (Opperand2 == 0) {
                throw new CantCalculateExeption();
            } else {
                return Opperand1 % Opperand2;
            }
        } else if (Operator == '+') {
            return Opperand1 + Opperand2;
        } else if (Operator == '-') {
            return Opperand1 - Opperand2;
        } else return 0;
    }

    private static long Calculate_unary(char Operator, long Opperand) {
        if (Operator == '~') {
            return (-1) * Opperand;
        } else return 0;
    }
    private static long Calculate_average(long[] Opperands, int num_Opperand) {
        long sum = 0;
        for(int i=0;i<num_Opperand;i++) {
            sum+=Opperands[i];
        }
        return sum/num_Opperand;
    }
}
