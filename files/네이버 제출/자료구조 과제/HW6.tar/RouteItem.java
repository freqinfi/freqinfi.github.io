public class RouteItem {

    public StringBuilder routeList;
    public int totalTime;

    public RouteItem(StringBuilder routeList, int totalTime){
        this.routeList=routeList;
        this.totalTime=totalTime;
    }

    public StringBuilder RouteItem2string(){
        return new StringBuilder(this.routeList);
    }
}
