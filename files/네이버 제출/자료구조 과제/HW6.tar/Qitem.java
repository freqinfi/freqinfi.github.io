import java.util.LinkedList;

public class Qitem implements Comparable<Qitem>{

    public String stationName;
    public String pastLineName;
    public RouteItem routeItem;

    public Qitem(String stationName, String pastLineName, RouteItem routeItem){

        this.stationName=stationName;
        this.pastLineName=pastLineName;
        this.routeItem = routeItem;

    }

    @Override
    public int compareTo(Qitem qitem){
        return this.routeItem.totalTime - qitem.routeItem.totalTime;
    }

}
