//정점에 저장하는 간선의 정보로 정점이 출발점이고, 도착점과 시간을 field로 갖는다.
public class Edge {

    private int timeTaken;
    private String destinationName;
    private String lineName;

    public Edge(int timeTaken, String destinationName, String lineName){

        this.timeTaken=timeTaken;
        this.destinationName=destinationName;
        this.lineName=lineName;

    }

    public String getDestinationName(){
        return destinationName;
    }

    public int getTimeTaken(){
        return timeTaken;
    }

    public String getLineName(){
        return lineName;
    }

    public Qitem edge2Qitem(RouteItem routeItem){
        return new Qitem(this.destinationName, this.lineName, routeItem);
    }

}
