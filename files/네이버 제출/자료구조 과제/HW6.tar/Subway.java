import java.io.*;
import java.io.FileReader;

public class Subway {
    public static SubwayMap subwaymap;
    public static BufferedWriter bw;

    public static void main(String[] args) {

        String subwayData = args[0];
        insertData(subwayData);

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        bw = new BufferedWriter(new OutputStreamWriter(System.out));

        while (true) {

            try {
                String input = br.readLine();
                if (input.compareTo("QUIT") == 0) {
                    bw.close();
                    break;
                }
                command(input);
            } catch (IOException e) {
                System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
            }
        }
    }

    private static void command(String input) {
        try {
            String[] dep_des = input.split(" ");
            if (dep_des.length == 2) {
                String[] routeString = subwaymap.displayRoute(dep_des[0], dep_des[1]);

                bw.write(routeString[0]);
                bw.newLine();
                bw.write(routeString[1]);
                bw.newLine();
                bw.flush();
            }
            else {
                System.out.println("Invalid command");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private static void insertData(String subwayData){

        File file = new File(subwayData);
        try {
            subwaymap = new SubwayMap();
            BufferedReader fileBr = new BufferedReader(new FileReader(file));
            String currentLine;

            //역 정보 넣기
            while(true) {
                currentLine = fileBr.readLine();

                if (currentLine == null || currentLine.equals("")) {
                    break;
                }
                String[] input_stationInfo = currentLine.split(" ");

                subwaymap.insertStation(input_stationInfo[0], input_stationInfo[1], input_stationInfo[2]);
            }

            //간선 정보 넣기
            while(true) {
                currentLine = fileBr.readLine();
                if (currentLine == null || currentLine.equals("")) {
                    break;
                }
                String[] input_edgeInfo = currentLine.split(" ");

                subwaymap.insertEdge(input_edgeInfo[0], input_edgeInfo[1], Integer.parseInt(input_edgeInfo[2]));
            }

            //환승 시간 넣기
            while(true) {
                currentLine = fileBr.readLine();
                if (currentLine == null || currentLine.equals("")) {
                    break;
                }
                String[] input_transitTime=currentLine.split(" ");

                subwaymap.insertTransittime(input_transitTime[0], Integer.parseInt(input_transitTime[1]));
            }

        } catch (IOException e) {
            System.out.println("파일을 찾을 수 없습니다.");
        }
    }
}
