import java.io.*;
import java.io.FileReader;
import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

public class Matching {
    final static int PATTERN_KEY_LENGTH = 6;
    static MyHashTable<PatternKey, Cordinate> hashTable;
    static int addLineNum = 0;

    //delete 함수를 위한 문장 전체를 관리하는 자료구조
    static LinkedList<String> dataStorage;

    public static void main(String args[]) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            try {
                String input = br.readLine();
                if (input.compareTo("QUIT") == 0)
                    break;

                command(input);
            } catch (IOException e) {
                System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
            }
        }
    }

    private static void command(String input) {
        char first_letter = input.charAt(0);

        switch (first_letter) {
            case '<': //데이터 입력
                buildHashtable(input.substring(2));
                return;

            case '@': //저장된 데이터 출력
                displayAllKey(Integer.parseInt(input.substring(2)));
                return;

            case '?': //패턴 검색
                searchPattern(input.substring(2));
                return;

            case '/'://문자열 삭제
                System.out.println(deletePattern(input.substring(2)));
                return;

            case '+'://문장 추가
                System.out.println(addLine(input.substring(2)));
                return;

            case 'A':
                for (String s : dataStorage) {
                    System.out.println(s);
                }
                return;
        }

    }

    // '<' 명령어 수행 함수
    private static void buildHashtable(String input_Filename) {

        hashTable = new MyHashTable<PatternKey, Cordinate>(100);
        dataStorage = new LinkedList<>();

        File input_file = new File(input_Filename);
        String current_line;
        String current_substr;
        addLineNum = 0;

        int line_number = 0;
        try {
            BufferedReader File_br = new BufferedReader(new FileReader(input_file));
            while (true) {

                current_line = File_br.readLine();
                addLineNum += 1;

                if (current_line == null) break;

                dataStorage.add(current_line);

                line_number += 1;
                if (current_line.length() < 6) continue;
                for (int j = 0; j < current_line.length() - PATTERN_KEY_LENGTH + 1; j++) {
                    current_substr = current_line.substring(j, j + PATTERN_KEY_LENGTH);
                    PatternKey key = new PatternKey(current_substr);
                    Cordinate key_cordinate = new Cordinate(line_number, j + 1);

                    hashTable.insertKey(key, key_cordinate);
                }
            }

        } catch (IOException e) {
            System.out.println("파일을 찾을 수 없습니다.");
        }
    }

    // '@' 명령어 수행 함수
    private static void displayAllKey(int slotNum) {
        MyAVLTree<PatternKey, Cordinate> targetTree = hashTable.tableList.get(slotNum);

        if (targetTree.isEmpty()) System.out.println("EMPTY");
        else targetTree.preOrderdisplay();
    }

    // '?' 명령어 수행 함수
    private static void searchPattern(String Pattern) {

        final Cordinate zeroCordinate = new Cordinate();
        int PATTERN_LENGTH = Pattern.length();

        if (PATTERN_LENGTH < PATTERN_KEY_LENGTH) {
            System.out.println("6글자 이상만 검색이 가능합니다.");
            return;
        }

        PatternKey Pattern_key = new PatternKey(Pattern.substring(0, PATTERN_KEY_LENGTH));
        MyAVLTreeNode<PatternKey, Cordinate> targetTreeNode = hashTable.searchKey(Pattern_key);

        if (targetTreeNode == MyAVLTree.NIL) {
            zeroCordinate.displayCordinate();
            System.out.println();
            return;
        }

        MyLinkedList<Cordinate> cordinateList = targetTreeNode.getCordinateList();

        if (cordinateList.isEmpty()) {
            zeroCordinate.displayCordinate();
            System.out.println();
            return;
        }

        //좌표 리스트에서 받아와서 pattern과 맞는지 확인해야한다.
        for (Cordinate cordinate : cordinateList) {

            int cordinate_line = cordinate.getLine_number(); //좌표에서 줄 위치
            int cordinate_letter = cordinate.getLetter_number(); //좌표에서 철자 위치
            int check_letter_location = PATTERN_KEY_LENGTH;

            while (check_letter_location + PATTERN_KEY_LENGTH - 1 < PATTERN_LENGTH) {
                //6개인 문자열을 재귀적으로 처리하는 것
                if (!hashTable.isExist_correctlocation(new PatternKey(Pattern.substring(check_letter_location, check_letter_location + PATTERN_KEY_LENGTH)),
                        new Cordinate(cordinate_line, cordinate_letter + check_letter_location))) {
                    cordinate.isCorrect = false;
                    break;
                }
                check_letter_location += 6;
            }

            //6개로 나눠떨어지지 않는 문자열을 처리하는 것
            if (cordinate.isCorrect && (PATTERN_LENGTH % 6) != 0) {

                check_letter_location = PATTERN_LENGTH - PATTERN_KEY_LENGTH;
                if (!hashTable.isExist_correctlocation(new PatternKey(Pattern.substring(check_letter_location, check_letter_location + PATTERN_KEY_LENGTH)),
                        new Cordinate(cordinate_line, cordinate_letter + check_letter_location))) {
                    cordinate.isCorrect = false;
                }

            }
        }
        boolean isEmpty = true;
        for (Cordinate cordinate : cordinateList) {
            if (cordinate.isCorrect) {
                if (!isEmpty) System.out.print(" ");
                isEmpty = false;
                cordinate.displayCordinate();
            }
        }
        if (isEmpty) {
            zeroCordinate.displayCordinate();
            System.out.println();
        } else System.out.println();
    }

    // '/' 명령어 수행 함수
    private static int deletePattern(String Pattern) {
        if(Pattern.length()!=PATTERN_KEY_LENGTH) System.out.println("/ 명령어는 6글자 패턴으로만 사용 가능");

        PatternKey targetPattern = new PatternKey(Pattern);
        MyAVLTreeNode<PatternKey, Cordinate> targetTreeNode = hashTable.searchKey(targetPattern);

        if (targetTreeNode == MyAVLTree.NIL) return 0;

        //삭제 대상 pattern의 좌표 List를 받는다.
        MyLinkedList<Cordinate> cordinateList = targetTreeNode.getCordinateList();

        //for loop에서 자신의 삭제를 막기 위해서 복제된 list 사용함.
        MyLinkedList<Cordinate> duplicatedCList = new MyLinkedList<>();

        for(Cordinate c: cordinateList){
            duplicatedCList.add(c);
        }

        int rvalue = cordinateList.size();

        int currentLine = cordinateList.first().getLine_number();

        // 줄에 있는 모든 좌표를 넘기기 위해서 존재
        Queue<Integer> currentList = new LinkedList<>();

        for (Cordinate cordinate : duplicatedCList) {

            if (cordinate.getLine_number() == currentLine) {
                currentList.add(cordinate.getLetter_number());
            } else {

                reHashing(currentLine, currentList);

                currentLine = cordinate.getLine_number();
                currentList.add(cordinate.getLetter_number());
            }
        }
        reHashing(currentLine, currentList);

        return rvalue;
    }

    // '+' 명령어 수행 함수
    private static int addLine(String addStr) {

        int line_number = addLineNum;
        if (addStr.length() < 6) return line_number;
        for (int j = 0; j < addStr.length() - PATTERN_KEY_LENGTH + 1; j++) {
            String addStr_subStr = addStr.substring(j, j + PATTERN_KEY_LENGTH);
            PatternKey key = new PatternKey(addStr_subStr);
            Cordinate key_cordinate = new Cordinate(line_number, j + 1);

            hashTable.insertKey(key, key_cordinate);
        }
        dataStorage.add(addStr);
        addLineNum+=1;
        return line_number;
    }

    private static Stack<Section> sectionList(Queue<Integer> queue) {

        Stack<Section> rStack = new Stack<>();

        int curr = queue.poll();
        rStack.push(new Section(curr, curr + 6));

        while (!queue.isEmpty()) {
            curr = queue.poll();
            if (curr < rStack.peek().getEnd()) {
                int realStart = rStack.pop().getStart();
                rStack.add(new Section(realStart, curr + 6));
            } else rStack.add(new Section(curr, curr + 6));
        }
        return rStack;
    }

    private static void reHashing(int currentLine, Queue<Integer> currentList){
        String currLineStr = dataStorage.get(currentLine - 1);

        int start=0;
        if(currentList.peek()-5>0) start=currentList.peek()-5;

        //먼저 rehashing을 위하여 기존의 있던 것들을 삭제하기

        for (int j = start; j < currLineStr.length() - PATTERN_KEY_LENGTH + 1; j++) {

            String current_substr = currLineStr.substring(j, j + PATTERN_KEY_LENGTH);
            PatternKey key = new PatternKey(current_substr);
            Cordinate key_cordinate = new Cordinate(currentLine, j + 1);

            hashTable.deleteCordinate(key, key_cordinate);
        }

        Stack<Section> deleteSectionList = sectionList(currentList);

        StringBuilder SB = new StringBuilder(currLineStr);

        while (!deleteSectionList.isEmpty()) {
            Section currSection = deleteSectionList.pop();
            SB.delete(currSection.getStart() - 1, currSection.getEnd() - 1);

        }
        currLineStr = new String(SB);
        dataStorage.set(currentLine - 1, currLineStr);

        for (int j = start; j < currLineStr.length() - PATTERN_KEY_LENGTH + 1; j++) {

            String current_substr = currLineStr.substring(j, j + PATTERN_KEY_LENGTH);
            PatternKey key = new PatternKey(current_substr);
            Cordinate key_cordinate = new Cordinate(currentLine, j + 1);

            hashTable.insertSorted(key, key_cordinate);
        }

    }
}

class Section{

    private int start;
    private int end;

    public int getStart() {
        return start;
    }
    public int getEnd() {
        return end;
    }

    public Section(int start, int end){
        this.start=start;
        this.end=end;
    }

    @Override
    public String toString(){
        return "["+start+"   "+end+"]";
    }

}

//교재 389~394p 참고함.
class MyAVLTree<K extends Comparable<K>, T extends Comparable<T>> {

    private MyAVLTreeNode<K,T> root;

    //루트 노드가 null일 때 BST와 비교해서 height=0임을 표시하기 위해 새롭게 비교할 객체가 필요함.
    // and null로 표시하면 깊이를 계산하지 못하지만 NIL로 표시하면 깊이를 계산하기 좋다.
    final static MyAVLTreeNode NIL = new MyAVLTreeNode(null, null, null, 0, null);

    public MyAVLTree(){
        root = NIL;
    }

    public int max(int num1, int num2){
        return (num1>num2) ? num1:num2;
    }

    public void renewalHeight(MyAVLTreeNode<K, T> tNode){
        tNode.height = max(tNode.leftChild.height,tNode.rightChild.height) + 1;
    }

    public MyAVLTreeNode<K, T> search(K searchFor){
        return searchItem(root, searchFor);
    }

    private MyAVLTreeNode<K, T> searchItem(MyAVLTreeNode<K, T> tNode, K searchFor){
        if(tNode==NIL){
            return NIL;
        }
        else if(tNode.Key.compareTo(searchFor) ==0){
            return tNode;
        }
        else if(tNode.Key.compareTo(searchFor) <0){
            return searchItem(tNode.rightChild, searchFor);
        }
        else{
            return searchItem(tNode.leftChild, searchFor);
        }
    }

    //AVL트리에 PATTERN스트링(KEY)를 삽입하는 함수이다.
    public void Insert(K input, T newCordinate){
        root = InsertItem(root, input, newCordinate);
    }

    private MyAVLTreeNode<K, T> InsertItem(MyAVLTreeNode<K, T> tNode, K input, T newCordinate){
        if(tNode==NIL){
            tNode = new MyAVLTreeNode<K, T>(input);
            tNode.firstinsertCordinate(newCordinate);
        }
        else if(tNode.Key.compareTo(input)>0){
            //재귀적으로 AVL트리를 내려가게 하는 코드
            tNode.leftChild = InsertItem(tNode.leftChild, input, newCordinate);
            //모두 내려가서 KEY 삽입 후 다시 올라가면서 균형을 맞추게 됨(삽입을 하는 경우에는 가장 처음에 균형이 맞으면 그다음에는 균형을 맞출 필요가 없다)
            renewalHeight(tNode);
            int type = judge_needBalance(tNode);
            if(type != NO_NEED) tNode = balanceMyAVLTree(type, tNode);
        }
        else if(tNode.Key.compareTo(input)==0){
            tNode.insertCordinate(newCordinate);
            return tNode;
        }
        else if(tNode.Key.compareTo(input)<0){
            //재귀적으로 AVL트리를 내려가게 하는 코드
            tNode.rightChild = InsertItem(tNode.rightChild, input, newCordinate);
            //모두 내려가서 KEY 삽입 후 다시 올라가면서 균형을 맞추게 됨(삽입을 하는 경우에는 가장 처음에 균형이 맞으면 그다음에는 균형을 맞출 필요가 없다)
            renewalHeight(tNode);
            int type = judge_needBalance(tNode);
            if(type != NO_NEED) tNode = balanceMyAVLTree(type, tNode);
        }
        return tNode;
    }

    public void delete(K input){
        this.root=deleteItem(this.root, input);
    }

    private MyAVLTreeNode<K,T> deleteItem(MyAVLTreeNode<K,T> tNode, K input){
        if(tNode==NIL) return NIL;
        else {
            if(input.compareTo(tNode.Key)==0) tNode=deleteNode(tNode);
            else if(input.compareTo(tNode.Key)<0){
                tNode.leftChild=deleteItem(tNode.leftChild, input);
                tNode.height=1+Math.max(tNode.rightChild.height,tNode.leftChild.height);
                int type=judge_needBalance(tNode);
                if(type != NO_NEED ) tNode=balanceMyAVLTree(type, tNode);
            }
            else {
                tNode.rightChild=deleteItem(tNode.rightChild, input);
                tNode.height=1+Math.max(tNode.rightChild.height,tNode.leftChild.height);
                int type=judge_needBalance(tNode);
                if(type != NO_NEED ) tNode=balanceMyAVLTree(type, tNode);
            }
        }
        return tNode;
    }

    private MyAVLTreeNode<K, T> deleteNode(MyAVLTreeNode<K, T> tNode){
        if((tNode.rightChild==NIL)&&(tNode.leftChild==NIL)) return NIL;
        else if(tNode.leftChild==NIL) return tNode.rightChild;
        else if(tNode.rightChild==NIL) return tNode.leftChild;
        else {
            returnPair<K> rPair=deleteMinItem(tNode.rightChild);
            tNode.Key=rPair.key;
            tNode.setCordinateList(rPair.cordinateList);
            tNode.rightChild=rPair.node;
            int type=judge_needBalance(tNode);

            if(type != NO_NEED ) tNode=balanceMyAVLTree(type, tNode);
            rPair.node=tNode;
            return tNode;
        }
    }

    private returnPair<K> deleteMinItem(MyAVLTreeNode<K, T> tNode){

        if(tNode.leftChild==NIL) return new returnPair<>(tNode.Key, tNode.rightChild, tNode.getCordinateList());
        else {
            returnPair<K> rPair=deleteMinItem(tNode.leftChild);
            tNode.leftChild=rPair.node;
            tNode.height=1+Math.max(tNode.rightChild.height,tNode.leftChild.height);
            int type=judge_needBalance(tNode);
            if(type != NO_NEED ) tNode=balanceMyAVLTree(type, tNode);
            rPair.node=tNode;
            return rPair;

        }
    }

    private class returnPair<K extends Comparable<K>> {
        private K key;
        private MyAVLTreeNode<K, T> node;
        private MyLinkedList<T> cordinateList;
        private returnPair(K input, MyAVLTreeNode<K,T>  nd, MyLinkedList<T> cordinateList){
            this.key=input;
            this.cordinateList=cordinateList;
            node=nd;
        }
    }

    //AVL트리의 균형을 맞추는 함수이다.
    private MyAVLTreeNode<K, T> balanceMyAVLTree(int type, MyAVLTreeNode<K, T> tNode){
        MyAVLTreeNode<K, T> returnNode = NIL;
        switch(type) {
            case LL:
                returnNode = rRotation(tNode);
                break;
            case LR:
                //왼자식으로 먼저 왼쪽회전을 하고, 자기 자신 기준으로 오른쪽 회전을 하면 균형이 맞춰진다.
                tNode.leftChild = lRotation(tNode.leftChild);
                returnNode = rRotation(tNode);
                break;
            case RL:
                //오른자식으로 먼저 오른쪽회전을 하고, 자기 자신 기준으로 왼쪽 회전을 하면 균형이 맞춰진다.
                tNode.rightChild = rRotation(tNode.rightChild);
                returnNode = lRotation(tNode);
                break;
            case RR:
                returnNode = lRotation(tNode);
                break;
            default:
                System.out.println("this type is impossible.");
                break;
        }

        return returnNode;
    }

    //대상 노드 기준으로 왼쪽 회전하는 함수
    private MyAVLTreeNode<K,T> lRotation(MyAVLTreeNode<K, T> tNode){

        MyAVLTreeNode<K,T> tNode_rChild = tNode.rightChild;
        if(tNode_rChild==NIL){
            System.out.println(tNode.Key + "'s RightChild shouldn't be NIL!");
        }
        else {
            MyAVLTreeNode<K, T> tNode_rChild_lChild = tNode_rChild.leftChild;
            tNode.rightChild=tNode_rChild_lChild;
            tNode_rChild.leftChild=tNode;
            renewalHeight(tNode);
            renewalHeight(tNode_rChild);
        }
        return tNode_rChild;
    }

    //대상 노드 기준으로 오른쪽 회전하는 함수
    private MyAVLTreeNode<K,T> rRotation(MyAVLTreeNode<K, T> tNode){

        MyAVLTreeNode<K,T> tNode_lChild = tNode.leftChild;
        if(tNode_lChild==NIL){
            System.out.println(tNode.Key + "'s leftChild shouldn't be NIL!");
        }
        else {
            MyAVLTreeNode<K, T> tNode_lChild_rChild = tNode_lChild.rightChild;
            tNode.leftChild=tNode_lChild_rChild;
            tNode_lChild.rightChild=tNode;
            renewalHeight(tNode);
            renewalHeight(tNode_lChild);
        }
        return tNode_lChild;
    }

    private final int LL=1, LR=2, RL=3, RR=4, NO_NEED = 0, ILLEGAL=-1;

    //균형잡는 것이 필요한지 판단하는 함수
    private int judge_needBalance(MyAVLTreeNode<K,T> tNode){
        int type = ILLEGAL;
        //l의 깊이가 더 깊은 경우(l타입) -> ll과 lr 손자의 깊이 계산 가능
        if(tNode.leftChild.height >= tNode.rightChild.height + 2){
            if(tNode.leftChild.leftChild.height >= tNode.leftChild.rightChild.height)  type = LL;
            else type = LR;
        }
        //r의 깊이가 더 깊은 경우(r타입) -> rl과 rr 손자의 깊이 계산 가능
        else if(tNode.leftChild.height + 2 <= tNode.rightChild.height) {
            if(tNode.rightChild.leftChild.height <= tNode.rightChild.rightChild.height) type = RR;
            else type = RL;
        }
        else type=NO_NEED;
        return type;
    }

    //기타 함수들

    public void preOrderdisplay(){
        preOrder(this.root);
        System.out.println();
    }

    private void preOrder(MyAVLTreeNode<K, T> tNode) {
        if(tNode != NIL) {
            if(tNode!=this.root) System.out.print(" ");

            System.out.print(tNode.Key.toString());
            if(tNode.leftChild != NIL) preOrder(tNode.leftChild);
            if(tNode.rightChild != NIL) preOrder(tNode.rightChild);
        }
    }

    public boolean isEmpty(){
        return root==NIL;
    }

    public void clear(){
        root=NIL;
    }
}

class MyAVLTreeNode<K extends Comparable<K>, T extends Comparable<T>>{

    public K Key;
    public MyAVLTreeNode<K,T> rightChild,leftChild;
    public int height;
    private MyLinkedList<T> CordinateList;

    //newKey만 받는 생성자
    public MyAVLTreeNode(K newKey){
        this.Key=newKey;
        this.rightChild=this.leftChild =MyAVLTree.NIL;
        this.height=1;
    }

    //모든 정보를 다 받는 생성자
    public MyAVLTreeNode(K newKey, MyAVLTreeNode<K,T> newLeft, MyAVLTreeNode<K,T> newRight, int height, MyLinkedList<T> cordinateList){
        this.Key=newKey;
        this.rightChild=newRight;
        this.leftChild=newLeft;
        this.height=height;
        this.CordinateList=cordinateList;
    }

    public MyLinkedList<T> getCordinateList(){
        return CordinateList;
    }

    public void setCordinateList(MyLinkedList<T> cordinateList){
        this.CordinateList=cordinateList;
    }

    public void firstinsertCordinate(T newCordinate){
        CordinateList=new MyLinkedList<T>();
        CordinateList.append(newCordinate);
    }

    public void insertCordinate(T newCordinate){
        CordinateList.append(newCordinate);
    }

    public boolean isExist_Cordinate(T input_cordinate){
        return this.CordinateList.isExist(input_cordinate);
    }

}


class MyHashTable<K extends Comparable<K>, T extends Comparable<T>>{

    public ArrayList<MyAVLTree<K, T>> tableList;

    public MyHashTable(int n){
        tableList = new ArrayList<MyAVLTree<K,T>>(n);
        for(int i=0;i<n;i++){
            tableList.add(new MyAVLTree<K, T>());
        }
    }

    public void insertKey(K input, T pairInteger){
        tableList.get(input.hashCode()).Insert(input, pairInteger);
    }

    public void insertSorted(K input, T pairInteger){

        MyAVLTreeNode<K,T> currNode=tableList.get(input.hashCode()).search(input);

        if(currNode==MyAVLTree.NIL) insertKey(input, pairInteger);
        else currNode.getCordinateList().sortedAdd(pairInteger);

    }

    public void deleteCordinate(K input, T pairInteger) {

        MyAVLTree<K, T> currTree=tableList.get(input.hashCode());

        MyAVLTreeNode<K,T> currTreeNode=currTree.search(input);

        currTreeNode.getCordinateList().removeItem(pairInteger);

        if(currTreeNode.getCordinateList().isEmpty()){
            currTree.delete(input);
        }

    }

    public MyAVLTreeNode<K, T> searchKey(K key){
        return this.tableList.get(key.hashCode()).search(key);
    }

    //원하는 위치에 원하는 stringkey가 있는지 확인하는 것
    public boolean isExist_correctlocation(K key, T expect_cordinaet){
        MyAVLTreeNode<K, T> expect_tNode = tableList.get(key.hashCode()).search(key);
        if(expect_tNode!=MyAVLTree.NIL){
            if(expect_tNode.isExist_Cordinate(expect_cordinaet)) return true;
            else return false;
        }
        else return false;
    }
}

interface ListInterface<T> extends Iterable<T> {
    public boolean isEmpty();

    public int size();

    public void add(T item);

    public T first();

    public void removeAll();
}

class MyLinkedList<T extends Comparable<T>> implements ListInterface<T> {

    Node<T> head;
    int numItems;

    public MyLinkedList() {
        head = new Node<T>(null);
    }

    public final Iterator<T> iterator() {
        return new MyLinkedListIterator<T>(this);
    }

    @Override
    public boolean isEmpty() {
        return head.getNext() == null;
    }

    @Override
    public int size() {
        return numItems;
    }

    @Override
    public T first() {
        return head.getNext().getItem();
    }

    @Override
    public void add(T item) {
        Node<T> last = head;
        while (last.getNext() != null) {
            last = last.getNext();
        }
        last.insertNext(item);
        numItems += 1;
    }

    @Override
    public void removeAll() {
        head.setNext(null);
    }

    public void append(T item){
        Node<T> prev = this.head;
        while(prev.getNext()!=null){
            prev=prev.getNext();
        }
        prev.setNext(new Node<T>(item));
        numItems+=1;
    }

    public void removeItem(T item){
        if(this.isEmpty()) return;

        Node<T> prev;
        Node<T> curr=head;
        for(int i=0;i<numItems;i++) {
            prev = curr;
            curr = curr.getNext();
            if (curr.getItem().compareTo(item) == 0) {
                prev.setNext(curr.getNext());
                numItems--;
            }
        }
    }

    public void sortedAdd(T item){
        if(numItems==0){
            this.add(item);
            numItems+=1;
        }
        else{
            Node<T> prev = head;
            Node<T> temp = head.getNext();
            if(temp!=null) {
                while (temp.getItem().compareTo(item) < 0) {
                    prev = prev.getNext();
                    temp = temp.getNext();
                    if (temp == null) {
                        break;
                    }
                }
            }
            Node<T> newnode = new Node<T>(item);
            prev.setNext(newnode);
            newnode.setNext(temp);
            numItems+=1;
        }
    }

    public boolean isExist(T check_item){
        for(T item : this){
            if(item.compareTo(check_item)==0){
                return true;
            }
        }
        return false;
    }
}

class MyLinkedListIterator<T extends Comparable<T>> implements Iterator<T> {

    private MyLinkedList<T> list;
    private Node<T> curr;
    private Node<T> prev;

    public MyLinkedListIterator(MyLinkedList<T> list) {
        this.list = list;
        this.curr = list.head;
        this.prev = null;
    }

    @Override
    public boolean hasNext() {
        return curr.getNext() != null;
    }

    @Override
    public T next() {
        if (!hasNext())
            throw new NoSuchElementException();

        prev = curr;
        curr = curr.getNext();

        return curr.getItem();
    }

    @Override
    public void remove() {
        if (prev == null)
            throw new IllegalStateException("next() should be called first");
        if (curr == null)
            throw new NoSuchElementException();
        prev.removeNext();
        list.numItems -= 1;
        curr = prev;
        prev = null;
    }
}

class Node<T> {

    private T item;
    private Node<T> next;

    public Node(T obj) {
        this.item = obj;
        this.next = null;
    }

    public Node(T obj, Node<T> next) {
        this.item = obj;
        this.next = next;
    }

    public final T getItem() {
        return item;
    }

    public final void setItem(T item) {
        this.item = item;
    }

    public final void setNext(Node<T> next) {
        this.next = next;
    }

    public Node<T> getNext() {
        return this.next;
    }

    public final void insertNext(T obj) {

        Node<T> newnode = new Node<T>(obj);
        newnode.next=this.next;
        this.next=newnode;

    }

    public final void removeNext(){

        if(this.next!=null){
            Node<T> temp = this.next;
            temp=temp.next;
        }
    }
}

class PatternKey implements Comparable<PatternKey>{

    private String pattern;

    public PatternKey(String pattern){
        this.pattern=pattern;
    }

    @Override
    public int hashCode(){
        int hashcode = 0;
        for(int i=0;i<this.pattern.length();i++){
            hashcode+=this.pattern.charAt(i);
        }
        return hashcode%=100;
    }

    @Override
    public String toString(){
        return pattern;
    }

    @Override
    public int compareTo(PatternKey patternkey){
        return this.pattern.compareTo(patternkey.pattern);
    }

}

class Cordinate implements Comparable<Cordinate>{

    private int line_number;
    private int letter_number;
    public boolean isCorrect;

    public Cordinate(){
        this.line_number=this.letter_number=0;
    }

    public Cordinate(int line, int letter){
        this.line_number=line;
        this.letter_number=letter;
        this.isCorrect = true;
    }

    public int getLine_number(){
        return line_number;
    }

    public int getLetter_number(){
        return letter_number;
    }

    @Override
    public int compareTo(Cordinate cordinate) {
        if(this.line_number==cordinate.line_number){
            return this.letter_number-cordinate.letter_number;
        }
        else{
            return this.line_number-cordinate.line_number;
        }
    }

    @Override
    public String toString(){
        StringBuilder MakeCordinate = new StringBuilder("(");
        MakeCordinate.append(line_number);
        MakeCordinate.append(", ");
        MakeCordinate.append(letter_number);
        MakeCordinate.append(")");
        return new String(MakeCordinate);
    }

    public void displayCordinate(){
        System.out.print(this.toString());
    }
}




